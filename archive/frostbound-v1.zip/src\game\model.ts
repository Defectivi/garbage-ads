import { Settlement } from './settlement';
export type Upgrade = 'pack' | 'boots' | 'efficiency' | 'output';
export type Upgrades = Record<Upgrade, number>;
export interface Save { version: 1; unlocked: number; selected: number; embers: number; best: number; sound: boolean; upgrades: Upgrades }
export interface Level { id: number; name: string; description: string; duration: number; startFuel: number; temperature: number; storm: number; size: number; rescue: boolean }
export const LEVELS: Level[] = [
  { id: 1, name: 'The first flame', description: 'Find your footing. Gather wood. Make it through the first storm.', duration: 60, startFuel: 16, temperature: -16, storm: 17, size: 1, rescue: false },
  { id: 2, name: 'Into the white', description: 'A colder night, a smaller fire. The forest asks a little more.', duration: 75, startFuel: 10, temperature: -22, storm: 20, size: 1.15, rescue: true },
  { id: 3, name: 'The long winter', description: 'Distant timber and a bitter storm. Bring every advantage.', duration: 90, startFuel: 8, temperature: -28, storm: 24, size: 1.3, rescue: true }
];
export const CAMP_LEVEL: Level = { id: 4, name: 'The winter settlement', description: 'Build a camp, recruit woodcutters and expand the warm clearing.', duration: 300, startFuel: 28, temperature: -14, storm: 16, size: 1.2, rescue: false };
export const UPGRADE_INFO: Record<Upgrade, { name: string; detail: string; icon: string }> = {
  pack: { name: 'Larger satchel', detail: '+3 wood capacity per tier', icon: 'pack' },
  boots: { name: 'Trail boots', detail: '+12% movement speed per tier', icon: 'boot' },
  efficiency: { name: 'Slow-burning fuel', detail: '15% less fuel used per tier', icon: 'log' },
  output: { name: 'Furnace bellows', detail: '+18% heat & range per tier', icon: 'fire' }
};
export function freshSave(): Save { return { version: 1, unlocked: 1, selected: 1, embers: 0, best: 0, sound: true, upgrades: { pack: 0, boots: 0, efficiency: 0, output: 0 } }; }
export function loadSave(): Save {
  try {
    const raw = JSON.parse(localStorage.getItem('frostbound-save') || 'null');
    if (!raw || raw.version !== 1) return freshSave();
    const s = freshSave();
    for (const k of ['unlocked', 'selected'] as const) s[k] = Math.max(1, Math.min(3, Math.floor(Number(raw[k]) || 1)));
    s.selected = Math.min(s.selected, s.unlocked);
    s.embers = Math.max(0, Math.min(99999, Math.floor(Number(raw.embers) || 0)));
    s.best = Math.max(0, Number(raw.best) || 0); s.sound = raw.sound !== false;
    for (const k of Object.keys(s.upgrades) as Upgrade[]) s.upgrades[k] = Math.max(0, Math.min(3, Math.floor(Number(raw.upgrades?.[k]) || 0)));
    return s;
  } catch { return freshSave(); }
}
export function saveProgress(save: Save) { try { localStorage.setItem('frostbound-save', JSON.stringify(save)); } catch { /* Play remains available if storage is disabled. */ } }
export class Survival {
  elapsed = 0; fuel: number; warmth = 100; wood = 0; stone = 0; gathered = 0; stoneGathered = 0; deposited = 0; rescued = false;
  readonly settlement = new Settlement();
  status: 'playing' | 'won' | 'lost' = 'playing';
  constructor(public level: Level, public upgrades: Upgrades) { this.fuel = level.startFuel; }
  get capacity() { return 6 + this.upgrades.pack * 3; }
  get speed() { return 170 * (1 + this.upgrades.boots * .12); }
  get environment() { return this.level.temperature - this.level.storm * Math.min(1, this.elapsed / this.level.duration); }
  get intensity() { return Math.min(1, this.fuel / 14); }
  get temperature() { return this.environment + this.intensity * 265 * (1 + this.upgrades.output * .18); }
  get radius() { return this.fuel > 0 ? ((100 + this.intensity * 100) * (1 + this.upgrades.output * .18) + this.settlement.expansions * 80) : 0; }
  get load() { return this.wood + this.stone; }
  collect(kind: 'wood' | 'stone' = 'wood') { if (this.status !== 'playing' || this.load >= this.capacity) return false; if (kind === 'wood') { this.wood++; this.gathered++; } else { this.stone++; this.stoneGathered++; } return true; }
  feedStock() { if (this.status !== 'playing' || this.settlement.wood < 1 || this.fuel > 80) return false; this.settlement.wood--; this.fuel += 5; this.deposited++; return true; }
  deposit() { if (this.status !== 'playing' || this.wood === 0) return 0; const n = this.wood; this.fuel = Math.min(85, this.fuel + n * 5); this.deposited += n; this.wood = 0; return n; }
  tick(dt: number, distance: number) {
    if (this.status !== 'playing') return;
    this.elapsed += dt;
    this.fuel = Math.max(0, this.fuel - dt * .95 * (1 - this.upgrades.efficiency * .15));
    const sheltered = this.fuel > 0 && distance < this.radius;
    this.warmth = Math.max(0, Math.min(100, this.warmth + dt * (sheltered ? 14 * this.intensity : -(2.1 + Math.abs(this.environment) * .105))));
    if (this.warmth <= 0) this.status = 'lost';
    else if (this.elapsed >= this.level.duration) this.status = 'won';
  }
}
