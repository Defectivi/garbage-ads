import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';
import { existsSync, mkdirSync } from 'node:fs';
const edge = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const browser = await chromium.launch({ headless: true, executablePath: process.env.BROWSER_EXECUTABLE || (existsSync(edge) ? edge : undefined) });
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
const errors = []; page.on('pageerror', e => errors.push(e.message));
mkdirSync('test-results', { recursive: true });
try {
  await page.goto('http://localhost:5173'); await page.locator('.camp-play').click();
  const setup = await page.evaluate(async () => {
    const { findRoute } = await import('/src/game/navigation.ts');
    const { scene: s, game } = window.__frostbound; game.loop.sleep();
    const step = () => { s.update(0, 50); if (!s.activeRound) throw new Error(`Camp ended early at ${s.model.elapsed}, warmth ${s.model.warmth}`); };
    const walk = (target) => {
      const route = findRoute(s.player, target, s.solids);
      if (!route.length) throw new Error(`No route to ${JSON.stringify(target)}`);
      for (const p of route) {
        let tries = 80;
        while (Math.hypot(s.player.x - p.x, s.player.y - p.y) > 7 && tries-- > 0) {
          const dx = p.x - s.player.x, dy = p.y - s.player.y, d = Math.hypot(dx, dy); s.stick = { x: dx / d, y: dy / d }; step();
        }
        if (tries <= 0) throw new Error(`Player stuck at ${s.player.x},${s.player.y}`);
      }
      s.stick = { x: 0, y: 0 }; for (let i = 0; i < 6; i++) step();
    };
    const returnToCamp = () => { walk({ x: s.home.x, y: s.home.y + 80 }); s.stash(); if (s.model.fuel < 18) { for (let i = 0; i < 4; i++) s.feedStock(); } for (let i = 0; i < 50; i++) step(); };
    const wood = s.sources.filter(v => v.kind === 'wood').sort((a, b) => a.x - b.x)[0];
    const history = [];
    for (let trip = 0; trip < 6 && s.model.settlement.wood < 10; trip++) {
      walk({ x: wood.x + 48, y: wood.y + 25 });
      s.actionHeld = true; for (let i = 0; i < 105; i++) step(); s.actionHeld = false;
      history.push({ trip, near: s.near, target: s.targetSource?.kind, wood: s.model.wood, stone: s.model.stone, x: s.player.x, y: s.player.y });
      returnToCamp();
      history.push({ stored: s.model.settlement.wood, near: s.near, x: s.player.x, y: s.player.y, wood: s.model.wood });
    }
    if (s.model.settlement.wood < 10) throw new Error(`Only ${s.model.settlement.wood} stored wood: ${JSON.stringify(history)}`);
    return { stock: s.model.settlement.wood, stone: s.model.settlement.stone, elapsed: s.model.elapsed, warmth: s.model.warmth };
  });
  await page.locator('#build-hut').click();
  assert.equal(await page.evaluate(() => window.__frostbound.scene.placementValid), true);
  const beforeHut = await page.evaluate(() => window.__frostbound.scene.model.settlement.availableWood(window.__frostbound.scene.model));
  // Invalid placement must not charge anything or spawn a worker.
  await page.evaluate(() => { const s = window.__frostbound.scene; s.setPlacementPoint(s.home); s.confirmPlacement(); });
  assert.equal(await page.evaluate(() => window.__frostbound.scene.workers.count), 0);
  assert.equal(await page.evaluate(() => window.__frostbound.scene.model.settlement.availableWood(window.__frostbound.scene.model)), beforeHut);
  await page.evaluate(() => { const s = window.__frostbound.scene; s.setPlacementPoint({ x: s.home.x - 135, y: s.home.y + 32 }); });
  await page.locator('#place-confirm').click();
  assert.equal(await page.evaluate(() => window.__frostbound.scene.workers.count), 1);
  assert.equal(await page.evaluate(() => window.__frostbound.scene.model.settlement.availableWood(window.__frostbound.scene.model)), beforeHut - 5);
  await page.locator('#build-hut').click(); await page.locator('#place-confirm').click();
  assert.equal(await page.evaluate(() => window.__frostbound.scene.workers.count), 2);
  const economy = await page.evaluate(() => {
    const s = window.__frostbound.scene;
    for (let i = 0; i < 3500 && s.model.settlement.wood < 30; i++) {
      s.update(0, 50);
      if (s.model.fuel < 15 && s.model.settlement.wood) s.feedStock();
      if (!s.activeRound) throw new Error(`Camp ended at ${s.model.elapsed}; worker wood ${s.model.settlement.workerWood}; ${JSON.stringify(s.workers.workers.map(w => ({ state: w.state, x: w.sprite.x, y: w.sprite.y, load: w.load, next: w.route[0], source: w.source && { x: w.source.x, y: w.source.y, stock: w.source.stock } })))}`);
    }
    return { bank: s.model.settlement.wood, delivered: s.model.settlement.workerWood, radius: s.model.radius, elapsed: s.model.elapsed };
  });
  assert(economy.delivered >= 30, JSON.stringify(economy)); assert(economy.bank >= 30);
  await page.locator('#expand-furnace').click();
  assert.equal(await page.evaluate(() => window.__frostbound.scene.model.radius), economy.radius + 80);
  assert.equal(await page.evaluate(() => window.__frostbound.scene.model.settlement.wood), economy.bank - 30);
  // Gather actual stone at a finite rock source and craft through the UI.
  const stone = await page.evaluate(async () => {
    const { findRoute } = await import('/src/game/navigation.ts'), s = window.__frostbound.scene;
    const target = s.sources.filter(v => v.kind === 'stone').sort((a, b) => Math.hypot(a.x - s.player.x, a.y - s.player.y) - Math.hypot(b.x - s.player.x, b.y - s.player.y))[0];
    const walk = (to) => {
      const route = findRoute(s.player, to, s.solids); if (!route.length) throw new Error('No route to stone');
      for (const p of route) { let attempts = 90; while (Math.hypot(s.player.x - p.x, s.player.y - p.y) > 7 && attempts-- > 0) { const dx = p.x - s.player.x, dy = p.y - s.player.y, d = Math.hypot(dx, dy); s.stick = { x: dx / d, y: dy / d }; s.update(0, 50); } }
      s.stick = { x: 0, y: 0 }; for (let i = 0; i < 6; i++) s.update(0, 50);
    };
    walk({ x: target.x + 45, y: target.y + 25 }); s.actionHeld = true;
    for (let i = 0; i < 100; i++) s.update(0, 50); s.actionHeld = false;
    walk({ x: s.home.x, y: s.home.y + 80 }); s.stash();
    return { gathered: s.model.stoneGathered, bank: s.model.settlement.stone };
  });
  assert(stone.gathered >= 5, JSON.stringify(stone));
  const bankStone = await page.evaluate(() => window.__frostbound.scene.model.settlement.stone);
  await page.locator('#stone-tools').click();
  assert.equal(await page.evaluate(() => window.__frostbound.scene.model.settlement.stoneTools), true);
  assert.equal(await page.evaluate(() => window.__frostbound.scene.model.settlement.stone), bankStone - 5);
  await page.evaluate(() => window.__frostbound.game.loop.wake());
  await page.waitForTimeout(1300); await page.screenshot({ path: 'test-results/settlement-desktop.png' });
  await page.setViewportSize({ width: 390, height: 844 }); await page.waitForTimeout(200); await page.screenshot({ path: 'test-results/settlement-mobile-controls.png' });
  await page.locator('.camp-toggle').click();
  await page.screenshot({ path: 'test-results/settlement-mobile.png' });
  await page.setViewportSize({ width: 1440, height: 1000 }); await page.waitForTimeout(100);
  await page.locator('.pause').click();
  const workerBank = await page.evaluate(() => window.__frostbound.scene.model.settlement.workerWood); await page.waitForTimeout(250);
  assert.equal(await page.evaluate(() => window.__frostbound.scene.model.settlement.workerWood), workerBank);
  await page.locator('.retry').click();
  assert.equal(await page.evaluate(() => window.__frostbound.scene.workers.count), 0);
  assert.equal(await page.evaluate(() => window.__frostbound.scene.model.settlement.expansions), 0);
  assert.equal(await page.evaluate(() => window.__frostbound.scene.model.level.id), 4);
  assert.deepEqual(errors, []); console.log('Camp browser checks passed: real gathering/storage, placement and collision validation, exact 5-wood hut costs, two physical workers delivering finite timber, 30-wood radius expansion, stone mining/axes, pause and clean restart.');
  console.log({ setup, economy, stone });
} finally { await browser.close(); }
