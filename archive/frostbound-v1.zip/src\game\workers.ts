import Phaser from 'phaser';
import type { Survival } from './model';
import { findRoute, resolveSolids, type Point, type Solid } from './navigation';
export interface TimberSource extends Point { stock: number; sprite: Phaser.GameObjects.Image; kind: 'wood' | 'stone' }
interface Worker { sprite: Phaser.GameObjects.Image; load: number; state: 'outbound' | 'chopping' | 'returning' | 'idle'; timer: number; route: Point[]; source?: TimberSource; bundle: Phaser.GameObjects.Image; label: Phaser.GameObjects.Text; phase: number }
export class WorkerSystem {
  private workers: Worker[] = [];
  constructor(private scene: Phaser.Scene, private home: Point, private sources: TimberSource[], private solids: Solid[]) {}
  get count() { return this.workers.length; }
  occupies(point: Point, radius: number) { return this.workers.some(w => Phaser.Math.Distance.BetweenPoints(w.sprite, point) < radius); }
  reroute() { for (const w of this.workers) { w.route = []; w.state = 'idle'; w.timer = 0; } }
  spawn(at: Point) {
    const sprite = this.scene.add.image(at.x, at.y + 65, 'worker').setOrigin(.5, .94).setScale(.64);
    const bundle = this.scene.add.image(sprite.x, sprite.y - 39, 'log').setScale(.5).setVisible(false);
    const label = this.scene.add.text(sprite.x, sprite.y - 63, 'WOODCUTTER', { fontFamily: 'sans-serif', fontSize: '8px', color: '#315269', backgroundColor: '#e4f0f1cc', padding: { x: 4, y: 3 } }).setOrigin(.5);
    this.workers.push({ sprite, bundle, label, load: 0, state: 'idle', timer: 0, route: [], phase: this.workers.length * 2 });
  }
  private returnHome(w: Worker) {
    w.state = 'returning'; w.route = findRoute(w.sprite, { x: this.home.x, y: this.home.y + 84 }, this.solids);
    if (!w.route.length) { w.state = 'idle'; w.timer = 2; }
  }
  update(dt: number, model: Survival) {
    for (const w of this.workers) {
      w.timer -= dt; w.phase += dt;
      if (w.state === 'idle' && w.timer <= 0) {
        if (w.load) this.returnHome(w);
        else {
          const sources = this.sources.filter(s => s.kind === 'wood' && s.stock > 0).sort((a, b) => Phaser.Math.Distance.BetweenPoints(w.sprite, a) - Phaser.Math.Distance.BetweenPoints(w.sprite, b));
          for (const source of sources) {
            const route = findRoute(w.sprite, { x: source.x + 57, y: source.y + 25 }, this.solids);
            if (route.length) { w.source = source; w.route = route; w.state = 'outbound'; break; }
          }
          if (w.state === 'idle') w.timer = 3;
        }
      }
      if (w.state === 'outbound' || w.state === 'returning') {
        const next = w.route[0];
        if (next) {
          const dx = next.x - w.sprite.x, dy = next.y - w.sprite.y, distance = Math.hypot(dx, dy), amount = Math.min(distance, dt * 105);
          const p = resolveSolids({ x: w.sprite.x + dx / (distance || 1) * amount, y: w.sprite.y + dy / (distance || 1) * amount }, this.solids, 12);
          w.sprite.setPosition(p.x, p.y).setFlipX(dx < 0).setRotation(Math.sin(w.phase * 15) * .055);
          if (distance < 7) w.route.shift();
        } else if (w.state === 'outbound') { w.state = 'chopping'; w.timer = model.settlement.stoneTools ? .55 : 1.1; }
        else {
          model.settlement.deliverWood(w.load); w.load = 0; w.state = 'idle'; w.timer = .3;
        }
      } else if (w.state === 'chopping' && w.timer <= 0) {
        if (w.source && w.source.stock > 0) { w.source.stock--; w.load++; w.timer = model.settlement.stoneTools ? .55 : 1.1; }
        if (w.load >= 3 || !w.source || w.source.stock <= 0) this.returnHome(w);
      }
      w.sprite.setDepth(w.sprite.y + 1);
      w.bundle.setPosition(w.sprite.x, w.sprite.y - 34).setVisible(w.load > 0).setDepth(w.sprite.y + 2);
      w.label.setPosition(w.sprite.x, w.sprite.y - 65).setText(w.state === 'chopping' ? 'CHOPPING' : w.state === 'returning' ? `${w.load} WOOD → CAMP` : w.state === 'idle' ? 'SEARCHING' : 'WOODCUTTER').setDepth(w.sprite.y + 3);
    }
  }
  destroy() { for (const w of this.workers) { w.sprite.destroy(); w.bundle.destroy(); w.label.destroy(); } this.workers = []; }
}
