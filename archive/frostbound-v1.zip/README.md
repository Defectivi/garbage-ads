# Frostbound

A complete, original HTML5 survival game with a shaded 2.5D winter forest. Gather wood and stone, build huts, recruit woodcutters, and keep a central furnace burning until the storm passes. Play short expeditions or develop a camp over a five-minute storm.

## Run locally

Requires Node.js 20.19+ or 22.12+ and npm.

```sh
npm install
npm run dev
```

Open **http://localhost:5173**. Vite also prints a LAN address for testing on a phone connected to the same network. On Windows PowerShell with restricted script execution, use `npm.cmd` instead of `npm`.

```sh
npm run typecheck
npm test
npm run build
npm run preview
```

The production site is generated in `dist/`. It can be served by any static host, including a subdirectory. Run through a web server rather than opening `index.html` as a file. No backend, accounts, API keys, advertisements, or paid services are required. All artwork and synthesized audio are created locally at runtime; fonts are bundled with the build.

## Controls

| Action | Desktop | Touch |
| --- | --- | --- |
| Move | WASD or arrow keys | Left joystick |
| Pick up wood or stone | Walk close to it | Walk close to it |
| Feed the furnace | E / Space, or click the prompt | Interact button / prompt |
| Chop a timber stump | Hold E / Space nearby | Hold Interact nearby |
| Mine a stone outcrop | Hold E / Space nearby | Hold Interact nearby |
| Store the pack at the furnace | R / Store pack | Camp → Store pack |
| Place a hut | B / Camp → Place hut; choose ground; E or Place hut | Camp → Place hut; tap ground; Place hut |
| Cancel placement | Escape / Cancel | Cancel |
| Expand heat or craft axes | Camp panel buttons | Camp panel buttons |
| Help a stranded hiker | E / Space nearby | Interact nearby |
| Pause / resume | Escape or pause button | Pause / resume buttons |
| Mute | Speaker button | Speaker button |

Furnace interaction burns all carried **wood** as fuel, leaving stone in your pack. With no carried wood, it burns one stored wood instead. **R / Store pack** transfers carried wood and stone into storage without burning anything. The separate **Feed 1 stored wood** button lets you refuel while reserving carried building materials. Empty inventories never create fuel. Wood and stone share pack capacity. Timber stumps and stone outcrops provide finite resources.

The small copper arrow at your feet shows your heading. The furnace's ground ring shows the heated area; regain warmth inside it while the fire has fuel. When the fire dwindles, its range and temperature decrease. If your warmth reaches zero, the expedition ends.

## Huts, workers, and furnace expansion

Choose **Build a winter camp** on the main menu for a 300-second session with more starting fuel and larger timber reserves. Building is also available during ordinary expeditions.

| Purchase | Cost | Effect |
| --- | --- | --- |
| Worker hut | **5 wood** | Place one snow-covered cabin and recruit one woodcutter; maximum four huts |
| Expand heat | **30 wood** each time | Add 80 world units to the actual furnace heat radius and enlarge its visible light/ring |
| Stone axes | **5 stone**, once per round | Workers chop twice as fast |

Purchases spend stored resources first, then carried resources. They never spend furnace fuel. Huts must be on clear ground inside the heated ring, away from the furnace, other huts, trees, rocks, people, and the central delivery apron. Select a green placement preview, then confirm; an invalid or cancelled placement costs nothing.

Workers physically walk to reachable timber, chop three logs, and bring them back to storage. They consume the same finite timber reserves as the player. No wood is credited until a worker arrives back at camp. Their paths avoid world solids and are recalculated when a hut is placed. Stored worker wood can be used for more huts, expansions, or furnace fuel. Workers do not automatically stoke the fire, and their movement/production pauses with the game.

Buildings, workers, resource reserves, stockpiles, axes, and furnace expansions belong to the current round and reset on retry; permanent ember upgrades and unlocked expeditions persist. An expanded furnace still needs fuel to produce warmth. On phones, tap the **Camp** header to open or collapse the building controls.

## Expeditions and progression

1. **The first flame** — 60 seconds, −16°C falling toward −33°C, 16 starting fuel, six-log satchel. Collect the close logs, feed the fire early, and make a second trip.
2. **Into the white** — 75 seconds, less starting fuel, a colder storm, more distant wood, a larger traversable area, and an optional stranded hiker.
3. **The long winter** — 90 seconds, the coldest storm, longest resource trips, and the largest traversable area.

Victories award 6 / 8 / 10 embers respectively, plus two for an optional rescue. Supplies give three tiers each of capacity (+3), speed (+12%), fuel efficiency (15% less fuel consumed), and furnace output (+18% heat/range). Prices are 4, 8, and 12 embers per tier. You can replay unlocked expeditions to earn supplies. There is no purchase or advertising requirement.

Progress and sound preferences persist under `frostbound-save` in LocalStorage. A corrupt or unavailable save falls back gracefully. Remove that key in browser storage to reset progression. Settings apply immediately; upgrades apply to the next expedition.

## Project structure

```text
src/
  main.ts               Phaser setup and UI wiring
  game/
    model.ts             Pure survival rules, levels, upgrades, validated save data
    ForestScene.ts       World, movement, collision, gathering, interactions, effects
    art.ts               Deterministic procedural canvas textures
    audio.ts             Optional synthesized effects and wind
    settlement.ts        Transactional building costs and shared resource stockpiles
    navigation.ts        Collision resolution and obstacle-aware A* routes
    workers.ts           Visible woodcutters, finite harvesting and physical deliveries
  ui.ts                  Menus, HUD, results, supplies, joystick, visibility pause
  style.css              Responsive desktop, portrait, and landscape layouts
tests/
  survival.test.ts       Simulation and save tests
  settlement.test.ts     Economy, stone, expansion, and navigation tests
  browser.mjs            Playwright browser integration checks
  camp-browser.mjs       Actual camp construction, worker deliveries, and expansion
```

Phaser 3 renders Canvas/WebGL and depth-sorts scenery. Movement uses acceleration/friction and circular solid collisions. The survival model takes frame-independent simulation time and distance in the projected heat zone. Simulation runs only during an active, unpaused expedition. Hiding the tab pauses the expedition; returning requires an explicit resume. Round startup clears temporary effects, rebuilds resources, and creates a fresh model. Scene input handlers are registered once; DOM controls are replaced with each screen.

The first expedition consumes 0.95 fuel/second. Each delivered log adds five fuel, with an 85-fuel ceiling. Fuel intensity controls furnace temperature, heat range, glow, and particles. Outside the ring, warmth loss increases with the environmental cold; inside a burning ring, warmth recovers with fire intensity. Standing by a neglected furnace eventually results in defeat. Two full early satchels can keep the first expedition alive.

## Browser checks

Start the development server in one terminal, then in another:

```sh
npx playwright install chromium
npm run test:browser
```

On Windows the test uses an installed Microsoft Edge if available. Otherwise it uses Playwright Chromium. You may set `BROWSER_EXECUTABLE` to another Chromium executable. Screenshots are written to `test-results/` (git-ignored).

The suite checks menu actions, real keyboard movement/pickups/deposits, solid furnace collision, pause, a winning expedition using actual timber interactions, natural defeat from neglect, retry, next level, purchases, persistence, touch joystick and fuel interaction, portrait/landscape resizing, and browser runtime errors. The camp scenario gathers physical resources, validates exact construction costs and invalid placement, recruits two workers, waits for real timber deliveries, buys a 30-wood expansion, mines stone, crafts axes, and checks pause/restart. Long survival sections use accelerated **scene updates** while retaining the actual movement, gathering, chopping, fuel and warmth systems. They do not overwrite fuel, warmth, inventory, or outcomes. Unit tests independently cover the underlying numerical simulation.

Verified during delivery: production build, TypeScript check, 13 simulation/economy/save/navigation tests, and both browser integration scenarios using headless Microsoft Edge at desktop and mobile viewport sizes. Physical iOS/Android device testing has not been performed.

## Assets and future intermissions

All environment, character, furnace, resource textures, and sound effects are original procedural work. DM Sans and Libre Caslon Display are bundled through Fontsource under the SIL Open Font License. Their license and copyright notices are included in `public/licenses/` and copied into every production build.

Results are the clean between-round boundary. The UI owns transitions; the model has no monetization dependency. No ad SDK, fake impressions, revenue counters, or gameplay interruptions are implemented. A future provider can attach to an optional between-round transition while leaving retry and continue available on provider failure.
