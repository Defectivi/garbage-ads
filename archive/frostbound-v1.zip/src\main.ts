import Phaser from 'phaser';
import { ForestScene } from './game/ForestScene';
import { AudioSystem } from './game/audio';
import { loadSave } from './game/model';
import { Interface } from './ui';
import '@fontsource/dm-sans/latin-400.css';
import '@fontsource/dm-sans/latin-500.css';
import '@fontsource/dm-sans/latin-600.css';
import '@fontsource/dm-sans/latin-700.css';
import '@fontsource/libre-caslon-display/latin-400.css';
import './style.css';
const save = loadSave(), audio = new AudioSystem(); audio.enabled = save.sound;
let ui: Interface;
const scene = new ForestScene(audio, { ready: () => { ui = new Interface(scene, save, audio); }, changed: () => ui?.refresh(), ended: () => ui.results(), pause: () => ui?.pause(), feedback: m => ui?.toast(m) });
const game = new Phaser.Game({ type: Phaser.AUTO, parent: 'game', backgroundColor: '#bed0db', scale: { mode: Phaser.Scale.RESIZE, width: window.innerWidth, height: window.innerHeight }, scene: [scene], render: { antialias: true, roundPixels: false }, input: { activePointers: 3 } });
// Development-only access for browser integration checks; excluded from production.
if (import.meta.env.DEV) Object.assign(window, { __frostbound: { game, scene } });
