import type { ForestScene } from './game/ForestScene';
import { CAMP_LEVEL, LEVELS, UPGRADE_INFO, saveProgress, type Save, type Upgrade } from './game/model';
import type { AudioSystem } from './game/audio';
const paths: Record<string, string> = {
  fire: '<path d="M12 2c1 5-5 5-2 10 1-3 4-3 4-6 4 4 6 7 4 11-3 7-13 5-13-1 0-4 3-6 3-8-1 5 3 5 4-6Z"/>',
  log: '<path d="m5 18 12-12M4 13l7 7M13 4l7 7"/><ellipse cx="6" cy="17" rx="4" ry="5" transform="rotate(-40 6 17)"/><path d="m9 20 11-11c3-4-3-9-6-6L3 14"/>',
  snow: '<path d="M12 2v20M3.3 7l17.4 10M3.3 17 20.7 7M8 4l4 3 4-3M8 20l4-3 4 3M3 11l5-1-1-5M21 13l-5 1 1 5M3 13l5 1-1 5M21 11l-5-1 1-5"/>',
  arrow: '<path d="M4 12h15m-6-6 6 6-6 6"/>',
  sound: '<path d="m11 4-5 4H2v8h4l5 4V4ZM15 8c3 2 3 6 0 8m3-11c5 4 5 10 0 14"/>',
  mute: '<path d="m11 4-5 4H2v8h4l5 4V4Zm5 5 6 6m0-6-6 6"/>',
  pause: '<path d="M8 5v14M16 5v14"/>',
  check: '<path d="m5 12 4 4L20 5"/>',
  mountain: '<path d="m2 20 7-14 5 8 3-5 6 11H2ZM6 12l3 2 3-2"/>',
  pack: '<rect x="5" y="6" width="14" height="16" rx="4"/><path d="M9 6V3h6v3M5 13h14M9 17h6"/>',
  boot: '<path d="M6 3h9v10l6 3v5H4v-8h2V3Z"/><path d="M10 6h5m-5 4h5M4 18h17"/>',
  close: '<path d="m6 6 12 12M18 6 6 18"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 6v7l4 2"/>',
  heart: '<path d="M12 21 3 12C-3 4 8-1 12 6 16-1 27 4 21 12l-9 9Z"/>',
  hut: '<path d="m2 11 10-8 10 8M5 9v12h14V9M10 21v-7h4v7"/>',
  stone: '<path d="m3 17 4-10 10-3 5 10-6 7H7l-4-4Zm4-10 5 8 10-1M12 15l-5 6"/>',
  range: '<circle cx="12" cy="12" r="6"/><path d="M12 1v4m0 14v4M1 12h4m14 0h4M4 4l3 3m10 10 3 3M4 20l3-3M17 7l3-3"/>',
};
export const icon = (key: string, cls = '') => `<svg class="icon ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[key] || paths.fire}</svg>`;
const time = (seconds: number) => `${Math.floor(seconds / 60).toString().padStart(2, '0')}:${Math.floor(seconds % 60).toString().padStart(2, '0')}`;
export class Interface {
  private root = document.querySelector<HTMLDivElement>('#interface')!;
  private view: 'menu' | 'game' | 'results' = 'menu'; private savedRound = false; private toastTimer?: number; private camp = false;
  constructor(private scene: ForestScene, private save: Save, private audio: AudioSystem) {
    document.addEventListener('visibilitychange', () => { if (document.hidden && scene.activeRound && !scene.paused) this.pause(); });
    this.menu();
  }
  private shell(content: string) {
    this.root.innerHTML = `<header class="brandbar"><a href="#" class="brand" aria-label="Frostbound main menu">${icon('mountain')}<span>FROSTBOUND<small>A WILDERNESS SURVIVAL GAME</small></span></a><div class="header-actions"><span class="edition">THE NORTHERN EXPEDITIONS <i></i> VOL. 01</span><button class="icon-button sound" aria-label="${this.save.sound ? 'Mute sound' : 'Enable sound'}" title="Toggle sound">${icon(this.save.sound ? 'sound' : 'mute')}</button>${this.view === 'game' ? `<button class="icon-button pause" aria-label="Pause game">${icon('pause')}</button>` : ''}</div></header>${content}<div id="toast" role="status"></div>`;
    this.root.querySelector('.brand')?.addEventListener('click', e => { e.preventDefault(); if (this.view === 'game') this.pause(); else this.menu(); });
    this.root.querySelector('.sound')!.addEventListener('click', () => {
      this.save.sound = !this.save.sound; this.audio.enabled = this.save.sound; this.audio.unlock(); this.audio.ambience(this.view === 'game' && !this.scene.paused); saveProgress(this.save);
      const btn = this.root.querySelector<HTMLButtonElement>('.sound')!; btn.innerHTML = icon(this.save.sound ? 'sound' : 'mute'); btn.setAttribute('aria-label', this.save.sound ? 'Mute sound' : 'Enable sound');
    });
    this.root.querySelector('.pause')?.addEventListener('click', () => this.pause());
  }
  menu() {
    this.view = 'menu'; this.camp = false; this.scene.menu(); this.root.className = 'menu-view';
    const level = LEVELS[this.save.selected - 1];
    this.shell(`<main class="menu-content"><div class="eyebrow"><span class="line"></span> THE FIRE IS ALL YOU HAVE</div><h1>A little fire.<br>A long <em>night.</em></h1><p class="intro">The forest is frozen. The storm is coming.<br>Gather wood, feed the furnace, and hold<br class="desktop-break"> on to your last bit of warmth.</p><div class="expedition-select"><label for="level">YOUR EXPEDITION</label><select id="level">${LEVELS.map(l => `<option value="${l.id}" ${l.id === this.save.selected ? 'selected' : ''} ${l.id > this.save.unlocked ? 'disabled' : ''}>${String(l.id).padStart(2, '0')} — ${l.name}${l.id > this.save.unlocked ? ' · Locked' : ''}</option>`).join('')}</select></div><button class="primary play">Enter the forest ${icon('arrow')}</button><div class="round-meta">${icon('clock')} ${level.duration} second expedition <span>·</span> No second chances for the fire</div><button class="workshop-link">${icon('pack')} Expedition supplies <span>${this.save.embers} embers</span>${icon('arrow')}</button></main><aside class="field-note"><span class="note-number">FIELD NOTE / 001</span><div class="note-line"></div><h3>Keep the fire alive.</h3><p>Out here, warmth is everything.<br>Never return empty-handed.</p><div class="coordinates">68° 21′ N &nbsp; / &nbsp; 17° 48′ E</div></aside><footer class="menu-footer"><div><span class="live-dot"></span> A SMALL SURVIVAL EXPERIENCE</div><span>MOVE. GATHER. RETURN. SURVIVE.</span><button class="how-link">How to play ${icon('arrow')}</button></footer>`);
    this.root.querySelector('.play')!.addEventListener('click', () => this.start());
    const camp = document.createElement('button'); camp.className = 'camp-play'; camp.innerHTML = `${icon('hut')} Build a winter camp <span>5 MIN</span>${icon('arrow')}`;
    this.root.querySelector('.play')!.after(camp); camp.addEventListener('click', () => this.start(true));
    this.root.querySelector<HTMLSelectElement>('#level')!.addEventListener('change', e => { this.save.selected = Number((e.target as HTMLSelectElement).value); saveProgress(this.save); this.menu(); });
    this.root.querySelector('.workshop-link')!.addEventListener('click', () => this.workshop());
    this.root.querySelector('.how-link')!.addEventListener('click', () => this.howTo());
  }
  start(camp = this.camp) {
    this.camp = camp;
    this.audio.unlock(); this.audio.enabled = this.save.sound; this.savedRound = false; this.view = 'game'; this.root.className = 'game-view';
    this.scene.start(camp ? CAMP_LEVEL : LEVELS[this.save.selected - 1], this.save.upgrades);
    this.shell(`<div class="hud"><div class="wood-stat stat">${icon('log')}<div><small>YOUR SATCHEL</small><strong id="wood">0 <span>/ 6</span></strong></div></div><div class="weather-stat stat">${icon('snow')}<div><small>OUTSIDE</small><strong id="outside">−16°<span>C</span></strong></div></div><div class="timer-stat stat"><div><small>SURVIVE THE STORM</small><strong id="timer">00:00 <span>/ 01:00</span></strong></div><div class="round-progress"><i id="round-fill"></i></div></div></div><div class="furnace-card"><div class="furnace-icon">${icon('fire')}</div><div class="furnace-data"><div><b>THE FURNACE</b><strong id="furnace-temp"></strong></div><div class="meter"><i id="fuel-fill"></i></div><small id="fuel-label"></small></div></div><div class="game-bottom"><div class="objective"><div class="eyebrow">YOUR NEXT MOVE</div><strong id="objective">Gather nearby wood</strong><small id="objective-hint">Walk over the logs to pick them up.</small></div><div class="warmth-card"><div class="warmth-heading">${icon('heart')}<span>BODY WARMTH</span><strong id="warmth-value">100%</strong></div><div class="meter"><i id="warmth-fill"></i></div><small id="warmth-hint">Stay within the furnace's warm circle.</small></div></div><button id="interact" class="interact hidden"><kbd>E</kbd><span></span>${icon('arrow')}</button><div class="keyboard-hint"><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> move <span>·</span> <kbd>E</kbd> interact <span>·</span> <kbd>ESC</kbd> pause</div><div class="touch-controls"><div id="joystick" aria-label="Movement joystick"><span class="stick-ring"></span><span id="stick-knob"></span></div><button id="touch-action" aria-label="Interact or hold to chop">${icon('fire')}<span>INTERACT</span></button></div><div class="cold-vignette"></div>`);
    this.root.querySelector('#interact')!.addEventListener('click', () => this.scene.interact());
    const dock = document.createElement('section'); dock.className = 'camp-dock';
    dock.innerHTML = `<button class="camp-toggle" aria-expanded="true">${icon('hut')} CAMP <span id="bank-summary"></span><span class="toggle-symbol">−</span></button><div class="camp-body"><div class="camp-resources"><span>${icon('log')} <b id="bank-wood">0</b> wood</span><span>${icon('stone')} <b id="bank-stone">0</b> stone</span><span id="worker-count">0 / 4 workers</span></div><div class="camp-actions"><button id="build-hut">${icon('hut')}<b>Place hut</b><small>5 wood · +1 worker</small></button><button id="expand-furnace">${icon('range')}<b>Expand heat</b><small>30 wood · +80 radius</small></button><button id="stone-tools">${icon('stone')}<b>Stone axes</b><small>5 stone · faster workers</small></button></div><div class="stock-actions"><button id="store-pack">Store pack <kbd>R</kbd></button><button id="feed-stock">Feed 1 stored wood</button></div><p class="camp-help">Workers deliver to storage. Store your pack at the furnace to save wood for building.</p></div><div class="placement-controls hidden"><strong id="placement-status">Choose clear ground</strong><small>Click or tap inside the warm ring. Green means ready.</small><div><button id="place-confirm">Place hut · 5 wood</button><button id="place-cancel">Cancel</button></div></div>`;
    this.root.appendChild(dock);
    const toggle = dock.querySelector<HTMLButtonElement>('.camp-toggle')!;
    if (window.innerWidth < 751) { dock.classList.add('collapsed'); toggle.setAttribute('aria-expanded', 'false'); }
    toggle.addEventListener('click', () => { dock.classList.toggle('collapsed'); toggle.setAttribute('aria-expanded', String(!dock.classList.contains('collapsed'))); });
    dock.querySelector('#build-hut')!.addEventListener('click', () => this.scene.beginPlacement());
    dock.querySelector('#expand-furnace')!.addEventListener('click', () => this.scene.expandFurnace());
    dock.querySelector('#stone-tools')!.addEventListener('click', () => this.scene.craftTools());
    dock.querySelector('#store-pack')!.addEventListener('click', () => this.scene.stash());
    dock.querySelector('#feed-stock')!.addEventListener('click', () => this.scene.feedStock());
    dock.querySelector('#place-confirm')!.addEventListener('click', () => this.scene.confirmPlacement());
    dock.querySelector('#place-cancel')!.addEventListener('click', () => { this.scene.cancelPlacement(); this.refresh(); });
    if (camp) this.toast('Build a hut with 5 wood. Store resources at the furnace with R.');
    this.setupTouch(); this.refresh();
  }
  refresh() {
    if (this.view !== 'game' || !this.scene.model || !this.root.querySelector('.camp-dock')) return;
    const m = this.scene.model;
    const html = (id: string, text: string) => { const el = document.getElementById(id); if (el) el.innerHTML = text; };
    const width = (id: string, n: number) => { const el = document.getElementById(id); if (el) el.style.width = `${n}%`; };
    html('wood', `${m.wood} <span>wood · ${m.stone} stone</span>`); this.root.querySelector('.wood-stat small')!.textContent = `PACK ${m.load} / ${m.capacity}`; html('outside', `−${Math.round(Math.abs(m.environment))}°<span>C</span>`);
    const economy = m.settlement;
    html('bank-wood', String(economy.wood)); html('bank-stone', String(economy.stone)); html('worker-count', `${economy.huts} / 4 workers`);
    html('bank-summary', `${economy.wood} wood · ${economy.stone} stone · ${economy.huts} workers`);
    const disabled = (id: string, value: boolean) => { const el = document.getElementById(id) as HTMLButtonElement | null; if (el) el.disabled = value; };
    disabled('build-hut', economy.availableWood(m) < 5 || economy.huts >= 4); disabled('expand-furnace', economy.availableWood(m) < 30);
    disabled('stone-tools', economy.stoneTools || economy.stone + m.stone < 5);
    disabled('store-pack', m.load === 0 || this.scene.near !== 'furnace'); disabled('feed-stock', economy.wood < 1 || m.fuel > 80 || this.scene.near !== 'furnace');
    const dock = this.root.querySelector('.camp-dock')!; dock.classList.toggle('placing', this.scene.placing);
    dock.querySelector('.placement-controls')!.classList.toggle('hidden', !this.scene.placing);
    html('placement-status', this.scene.placementValid ? 'Ready to build · 1 woodcutter joins camp' : 'Blocked · choose clear ground inside the warm ring'); disabled('place-confirm', !this.scene.placementValid);
    if (economy.stoneTools) this.root.querySelector('#stone-tools small')!.textContent = 'Crafted · 2× chop speed';
    html('timer', `${time(m.elapsed)} <span>/ ${time(m.level.duration)}</span>`); width('round-fill', m.elapsed / m.level.duration * 100);
    html('furnace-temp', `${Math.round(m.temperature)}°C`); html('fuel-label', `${m.fuel.toFixed(0)} fuel · ${m.intensity > .6 ? 'Burning bright' : m.fuel > 0 ? 'Fire fading' : 'Fire extinguished'}`); width('fuel-fill', Math.min(100, m.fuel / 55 * 100));
    html('warmth-value', `${Math.ceil(m.warmth)}%`); width('warmth-fill', m.warmth);
    const safe = Math.hypot(this.scene.player.x - this.scene.home.x, (this.scene.player.y - this.scene.home.y) / .69) < m.radius && m.fuel > 0;
    html('warmth-hint', safe ? 'By the fire · warmth recovering' : 'Exposed to the cold · return before you freeze');
    this.root.classList.toggle('danger', m.warmth < 30);
    html('objective', m.fuel < 10 ? 'The fire needs more wood' : !m.gathered ? 'Gather nearby wood' : this.camp && !economy.huts ? 'Build your first hut · 5 wood' : m.load >= m.capacity ? 'Pack full · return to camp' : m.warmth < 45 ? 'Return to the warmth' : this.camp && !economy.expansions ? 'Expand the furnace · 30 wood' : 'Keep the fire alive');
    html('objective-hint', !m.gathered ? 'Walk over logs and stones to pick them up.' : this.camp && !economy.huts ? 'Camp → Place hut. Each hut recruits a woodcutter.' : this.camp ? `Workers gathered ${economy.workerWood} wood. ${economy.expansions} heat expansions.` : m.level.rescue && !m.rescued ? 'Optional: find the hiker east of the furnace.' : 'Burn wood with E. Store resources with R for building.');
    const interact = this.root.querySelector<HTMLButtonElement>('#interact');
    interact?.classList.toggle('hidden', !this.scene.prompt); if (interact) interact.querySelector('span')!.textContent = this.scene.prompt;
    this.root.querySelector('#touch-action')?.classList.toggle('available', !!this.scene.near);
  }
  private setupTouch() {
    const joystick = this.root.querySelector<HTMLElement>('#joystick')!, knob = this.root.querySelector<HTMLElement>('#stick-knob')!;
    let pointer: number | undefined;
    const move = (e: PointerEvent) => { if (pointer !== e.pointerId) return; const b = joystick.getBoundingClientRect(); let x = e.clientX - b.x - b.width / 2, y = e.clientY - b.y - b.height / 2; const d = Math.hypot(x, y); if (d > 40) { x *= 40 / d; y *= 40 / d; } this.scene.stick = { x: x / 40, y: y / 40 }; knob.style.transform = `translate(${x}px, ${y}px)`; };
    joystick.addEventListener('pointerdown', e => { pointer = e.pointerId; joystick.setPointerCapture(pointer); move(e); }); joystick.addEventListener('pointermove', move);
    const release = () => { pointer = undefined; this.scene.stick = { x: 0, y: 0 }; knob.style.transform = ''; };
    joystick.addEventListener('pointerup', release); joystick.addEventListener('pointercancel', release); joystick.addEventListener('lostpointercapture', release);
    const action = this.root.querySelector<HTMLElement>('#touch-action')!;
    action.addEventListener('pointerdown', e => { action.setPointerCapture(e.pointerId); this.scene.actionHeld = true; this.scene.interact(); });
    for (const event of ['pointerup', 'pointercancel', 'lostpointercapture']) action.addEventListener(event, () => { this.scene.actionHeld = false; });
  }
  pause() {
    if (this.view !== 'game') return;
    if (this.scene.paused) { this.closeModal(); this.scene.setPaused(false); return; }
    this.scene.setPaused(true);
    this.modal(`<div class="eyebrow">TAKE A BREATH</div><h2>The forest can wait.</h2><p>Your expedition is paused.</p><button class="primary resume">Return to the fire ${icon('arrow')}</button><button class="secondary retry">Restart expedition</button><button class="text-button leave">Back to main menu</button>`);
    this.root.querySelector('.resume')!.addEventListener('click', () => this.pause());
    this.root.querySelector('.retry')!.addEventListener('click', () => this.start());
    this.root.querySelector('.leave')!.addEventListener('click', () => this.menu());
  }
  results() {
    const m = this.scene.model!; const won = m.status === 'won'; this.view = 'results'; this.root.className = 'results-view';
    const objectives = [m.gathered > 0, m.deposited > 0, won]; const reward = won ? 4 + m.level.id * 2 + (m.rescued ? 2 : 0) : 0;
    if (!this.savedRound) { this.savedRound = true; this.save.embers += reward; this.save.best = Math.max(this.save.best, m.elapsed); if (won && m.level.id <= 3) this.save.unlocked = Math.max(this.save.unlocked, Math.min(3, m.level.id + 1)); saveProgress(this.save); }
    this.shell(`<main class="result-panel"><div class="result-symbol ${won ? '' : 'lost'}">${icon(won ? 'fire' : 'snow')}</div><div class="eyebrow">EXPEDITION ${String(m.level.id).padStart(2, '0')} / ${won ? 'COMPLETE' : 'LOST TO THE COLD'}</div><h2>${won ? 'You kept the<br><em>night at bay.</em>' : 'The cold<br><em>closed in.</em>'}</h2><p>${won ? 'The storm has passed. Your fire is still burning.' : 'Every trip counts. Feed the furnace early and warm up often.'}</p><div class="result-stats"><div><strong>${time(Math.min(m.elapsed, m.level.duration))}</strong><small>SURVIVED</small></div><div><strong>${m.gathered}</strong><small>WOOD GATHERED</small></div><div><strong>${m.deposited}</strong><small>WOOD FED</small></div></div><div class="objectives-list">${['Gather wood from the clearing', 'Add fuel to the furnace', 'Survive the storm'].map((o, i) => `<div class="${objectives[i] ? 'done' : ''}"><span>${objectives[i] ? icon('check') : '—'}</span>${o}</div>`).join('')}${m.level.rescue ? `<div class="${m.rescued ? 'done' : ''}"><span>${m.rescued ? icon('check') : '—'}</span>Optional: rescue the stranded hiker</div>` : ''}</div>${won ? `<div class="reward">${icon('fire')} +${reward} embers <span>Spend on expedition supplies</span></div>` : ''}<button class="primary continue">${won && m.level.id < 3 ? 'Next expedition' : 'Try again'} ${icon('arrow')}</button><div class="result-buttons"><button class="retry text-button">Retry expedition</button><button class="supplies text-button">Supplies</button><button class="leave text-button">Main menu</button></div></main>`);
    this.root.querySelector('.continue')!.addEventListener('click', () => { if (won && m.level.id < 3) { this.save.selected = m.level.id + 1; saveProgress(this.save); } this.start(); });
    const settlementStats = document.createElement('div'); settlementStats.className = 'settlement-results'; settlementStats.textContent = `${m.stoneGathered} stone gathered · ${m.settlement.huts} huts · ${m.settlement.workerWood} worker wood · ${m.settlement.expansions} heat expansions`;
    this.root.querySelector('.result-stats')!.after(settlementStats);
    this.root.querySelector('.retry')!.addEventListener('click', () => this.start()); this.root.querySelector('.supplies')!.addEventListener('click', () => this.workshop()); this.root.querySelector('.leave')!.addEventListener('click', () => this.menu());
  }
  private modal(content: string, wide = false) { this.closeModal(); const el = document.createElement('div'); el.className = 'modal-backdrop'; el.innerHTML = `<section class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true">${content}</section>`; this.root.appendChild(el); el.querySelector<HTMLElement>('button')?.focus(); }
  private closeModal() { this.root.querySelector('.modal-backdrop')?.remove(); }
  private workshop() {
    this.modal(`<button class="modal-close icon-button" aria-label="Close supplies">${icon('close')}</button><div class="eyebrow">A LITTLE BETTER PREPARED</div><h2>Expedition supplies.</h2><p>Earn embers by surviving. Every improvement lasts.</p><div class="balance">${icon('fire')} <b>${this.save.embers}</b> embers available</div><div class="upgrade-list">${(Object.keys(UPGRADE_INFO) as Upgrade[]).map(key => { const u = UPGRADE_INFO[key], tier = this.save.upgrades[key], price = (tier + 1) * 4; return `<div class="upgrade">${icon(u.icon)}<div><strong>${u.name}</strong><small>${u.detail}</small><div class="tiers">${[0, 1, 2].map(i => `<i class="${i < tier ? 'filled' : ''}"></i>`).join('')}</div></div><button data-upgrade="${key}" ${tier >= 3 || price > this.save.embers ? 'disabled' : ''}>${tier >= 3 ? 'MAX' : `${price} embers`}</button></div>`; }).join('')}</div>`, true);
    this.root.querySelector('.modal-close')!.addEventListener('click', () => this.closeModal());
    this.root.querySelectorAll<HTMLButtonElement>('[data-upgrade]').forEach(btn => btn.addEventListener('click', () => { const key = btn.dataset.upgrade as Upgrade, price = (this.save.upgrades[key] + 1) * 4; if (this.save.upgrades[key] < 3 && this.save.embers >= price) { this.save.embers -= price; this.save.upgrades[key]++; saveProgress(this.save); this.audio.tone('collect'); if (this.view === 'menu') this.menu(); this.workshop(); } }));
  }
  private howTo() {
    this.modal(`<button class="modal-close icon-button" aria-label="Close instructions">${icon('close')}</button><div class="eyebrow">YOUR FIRST NIGHT</div><h2>One fire. One chance.</h2><ol class="instructions"><li><b>Move through the clearing.</b> Use WASD, arrow keys, or the touch joystick.</li><li><b>Gather fallen wood.</b> Walk over logs. Hold E or interact beside a stump to chop timber.</li><li><b>Feed the furnace.</b> Approach it and press E, Space, or the interact button. All carried wood becomes fuel.</li><li><b>Mind your warmth.</b> The fire's circle is your shelter. Warm up before another trip.</li><li><b>Outlast the storm.</b> Survive 60 seconds to unlock your next expedition and earn upgrades.</li></ol><button class="primary got-it">Into the forest ${icon('arrow')}</button>`, true);
    this.root.querySelector('.modal-close')!.addEventListener('click', () => this.closeModal()); this.root.querySelector('.got-it')!.addEventListener('click', () => this.start());
    const settlementTip = document.createElement('li'); settlementTip.innerHTML = '<b>Build a winter camp.</b> Choose the five-minute camp from the main menu. Store wood and stone at the furnace with R / Store pack. Place a hut for 5 wood, expand heat for 30 wood, and craft worker axes for 5 stone. Each hut sends out a woodcutter who brings timber back to storage.';
    this.root.querySelector('.instructions')!.appendChild(settlementTip);
  }
  toast(message: string) { const el = document.getElementById('toast'); if (!el) return; el.textContent = message; el.classList.add('show'); clearTimeout(this.toastTimer); this.toastTimer = window.setTimeout(() => el.classList.remove('show'), 2600); }
}
