export interface Pack { wood: number; stone: number }
export const HUT_COST = 5;
export const RANGE_COST = 30;
export const TOOLS_COST = 5;
export const MAX_HUTS = 4;

/** Round-local economy. Fuel, stockpiled resources and carried resources stay distinct. */
export class Settlement {
  wood = 0;
  stone = 0;
  huts = 0;
  expansions = 0;
  stoneTools = false;
  workerWood = 0;
  availableWood(pack: Pack) { return this.wood + pack.wood; }
  stash(pack: Pack) {
    const count = pack.wood + pack.stone;
    this.wood += pack.wood; this.stone += pack.stone;
    pack.wood = 0; pack.stone = 0;
    return count;
  }
  private spendWood(cost: number, pack: Pack) {
    if (this.availableWood(pack) < cost) return false;
    const banked = Math.min(this.wood, cost);
    this.wood -= banked; pack.wood -= cost - banked;
    return true;
  }
  buildHut(pack: Pack) {
    if (this.huts >= MAX_HUTS || !this.spendWood(HUT_COST, pack)) return false;
    this.huts++; return true;
  }
  expand(pack: Pack) {
    if (!this.spendWood(RANGE_COST, pack)) return false;
    this.expansions++; return true;
  }
  craftTools(pack: Pack) {
    if (this.stoneTools || this.stone + pack.stone < TOOLS_COST) return false;
    const banked = Math.min(this.stone, TOOLS_COST);
    this.stone -= banked; pack.stone -= TOOLS_COST - banked; this.stoneTools = true;
    return true;
  }
  deliverWood(count: number) { this.wood += count; this.workerWood += count; }
}
