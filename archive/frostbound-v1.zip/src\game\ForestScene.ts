import Phaser from 'phaser';
import { createArt, seeded } from './art';
import { Survival, type Level, type Upgrades } from './model';
import { AudioSystem } from './audio';
import { type Solid, type Point, resolveSolids } from './navigation';
import { WorkerSystem, type TimberSource } from './workers';
import { HUT_COST, MAX_HUTS } from './settlement';
interface Resource { x: number; y: number; sprite: Phaser.GameObjects.Image; taken: boolean; kind?: 'wood' | 'stone' }
export interface SceneHooks { ready: () => void; changed: () => void; ended: () => void; pause: () => void; feedback: (message: string) => void }
export class ForestScene extends Phaser.Scene {
  model?: Survival; activeRound = false; paused = false;
  player!: Phaser.GameObjects.Image; readonly home = { x: 1024, y: 900 };
  stick = { x: 0, y: 0 }; actionHeld = false; prompt = ''; near: 'furnace' | 'source' | 'rescue' | '' = '';
  placing = false; placementValid = false; private placement = { x: 0, y: 0 }; private ghost?: Phaser.GameObjects.Image;
  workers?: WorkerSystem;
  private solids: Solid[] = []; private resources: Resource[] = []; private sources: TimberSource[] = [];
  private scenery!: Phaser.GameObjects.Group; private effects!: Phaser.GameObjects.Group; private glow!: Phaser.GameObjects.Image; private heat!: Phaser.GameObjects.Graphics; private direction!: Phaser.GameObjects.Graphics;
  private fire!: Phaser.GameObjects.Particles.ParticleEmitter; private smoke!: Phaser.GameObjects.Particles.ParticleEmitter;
  private snow!: Phaser.GameObjects.Particles.ParticleEmitter; private sparks!: Phaser.GameObjects.Particles.ParticleEmitter; private furnace!: Phaser.GameObjects.Image;
  private cursors!: Phaser.Types.Input.Keyboard.CursorKeys; private keys!: Record<string, Phaser.Input.Keyboard.Key>;
  private velocity = { x: 0, y: 0 }; private clock = 0; private chop = 0; private uiClock = 0; private warning = 0; private trail = 0;
  private rescue?: Phaser.GameObjects.Text; private targetSource?: TimberSource; private facing = { x: 0, y: 1 }; private mapScale = 1;
  constructor(public audio: AudioSystem, private hooks: SceneHooks) { super('forest'); }
  create() {
    createArt(this); this.scenery = this.add.group(); this.effects = this.add.group(); this.buildForest(1);
    const h = this.home;
    this.heat = this.add.graphics().setDepth(.2);
    this.glow = this.add.image(h.x, h.y - 8, 'glow').setDepth(.3).setScale(1.05, .72);
    this.furnace = this.add.image(h.x, h.y + 10, 'furnace').setOrigin(.5, .94).setDepth(h.y + 12);
    this.fire = this.add.particles(h.x, h.y - 42, 'particle', { speedX: { min: -12, max: 12 }, speedY: { min: -35, max: -75 }, lifespan: { min: 200, max: 550 }, frequency: 40, scale: { start: .9, end: .1 }, tint: [0xffe6a1, 0xffae40, 0xff7834], blendMode: 'ADD' }).setDepth(h.y + 14);
    this.smoke = this.add.particles(h.x, h.y - 192, 'particle', { speedX: { min: 10, max: 28 }, speedY: { min: -18, max: -40 }, lifespan: 2100, frequency: 140, scale: { start: 1.1, end: 4 }, alpha: { start: .15, end: 0 }, tint: 0x72838b }).setDepth(h.y + 15);
    this.sparks = this.add.particles(0, 0, 'particle', { emitting: false, speed: { min: 30, max: 85 }, lifespan: 500, scale: { start: .4, end: 0 }, tint: 0xffd080, blendMode: 'ADD' }).setDepth(2500);
    this.player = this.add.image(h.x + 40, h.y + 150, 'survivor').setOrigin(.5, .94).setScale(.72);
    this.direction = this.add.graphics().setDepth(.5);
    this.snow = this.add.particles(0, 0, 'particle', { x: { min: 0, max: this.scale.width }, y: -20, lifespan: 16000, speedY: { min: 30, max: 75 }, speedX: { min: -24, max: -10 }, frequency: 75, scale: { min: .09, max: .27 }, alpha: { min: .3, max: .8 } }).setScrollFactor(0).setDepth(4000);
    this.cursors = this.input.keyboard!.createCursorKeys();
    this.keys = this.input.keyboard!.addKeys('W,A,S,D,E,SPACE,ESC,B,R') as Record<string, Phaser.Input.Keyboard.Key>;
    this.input.keyboard!.addCapture(['UP', 'DOWN', 'LEFT', 'RIGHT', 'SPACE']);
    this.keys.E.on('down', () => this.interact()); this.keys.SPACE.on('down', () => this.interact()); this.keys.ESC.on('down', () => { if (this.placing) this.cancelPlacement(); else if (this.activeRound) this.hooks.pause(); });
    this.keys.B.on('down', () => this.placing ? this.cancelPlacement() : this.beginPlacement());
    this.keys.R.on('down', () => this.stash());
    this.input.on('pointerdown', (pointer: Phaser.Input.Pointer) => { if (this.placing) { const p = this.cameras.main.getWorldPoint(pointer.x, pointer.y); this.setPlacementPoint(p); } });
    this.input.on('pointermove', (pointer: Phaser.Input.Pointer) => { if (this.placing && !pointer.wasTouch) this.setPlacementPoint(this.cameras.main.getWorldPoint(pointer.x, pointer.y)); });
    this.scale.on('resize', this.resize, this); this.resize(); this.hooks.ready();
  }
  private buildForest(level: number) {
    this.workers?.destroy(); this.cancelPlacement(); this.scenery.clear(true, true); this.solids = [{ x: this.home.x, y: this.home.y - 13, radius: 51 }]; this.resources = []; this.sources = [];
    const ground = this.add.image(1024, 900, 'ground').setDepth(-10); this.scenery.add(ground);
    const r = seeded(509), h = this.home;
    for (let y = 70; y < 1770; y += 94) for (let x = 65; x < 2000; x += 86) {
      const tx = x + (r() - .5) * 64, ty = y + (r() - .5) * 55;
      const dist = Math.hypot((tx - h.x) / 1.13, ty - h.y);
      if (dist < 360 || (dist < 470 && r() > .30) || r() < .12) continue;
      const scale = .7 + r() * .55;
      const tree = this.add.image(tx, ty, `pine${Math.floor(r() * 3)}`).setOrigin(.5, .93).setScale(scale).setDepth(ty);
      this.scenery.add(tree); this.solids.push({ x: tx, y: ty - 4, radius: 16 * scale });
    }
    for (let i = 0; i < 14; i++) {
      const a = r() * Math.PI * 2, d = 295 + r() * 130, x = h.x + Math.cos(a) * d, y = h.y + Math.sin(a) * d * .83;
      if ([[-235, 95], [260, -130], [-80, -300]].some(([dx, dy]) => Math.hypot(x - (h.x + dx * (1 + (level - 1) * .12)), y - (h.y + dy)) < 125)) continue;
      const rock = this.add.image(x, y, 'rock').setOrigin(.5, .85).setScale(.55 + r() * .4).setDepth(y); this.scenery.add(rock); this.solids.push({ x, y, radius: 22 }); this.sources.push({ x, y, sprite: rock, stock: 12, kind: 'stone' });
    }
    // Nearby timber teaches gathering; later rings require longer trips into the storm.
    for (let i = 0; i < 42; i++) {
      const a = i * 2.399, d = i < 9 ? 106 + i * 13 : 190 + r() * (150 + level * 35);
      const x = h.x + Math.cos(a) * d, y = h.y + Math.sin(a) * d * .85;
      if (this.solids.some(s => Math.hypot(s.x - x, s.y - y) < s.radius + 25)) continue;
      const sprite = this.add.image(x, y, 'log').setRotation((r() - .5) * 1.6).setScale(.8).setDepth(y); this.scenery.add(sprite); this.resources.push({ x, y, sprite, taken: false });
    }
    // Two guaranteed pickups beside the starting position.
    for (const [dx, dy] of [[42, 115], [72, 140]]) {
      const x = h.x + dx, y = h.y + dy, sprite = this.add.image(x, y, 'log').setDepth(y).setScale(.8); this.scenery.add(sprite); this.resources.push({ x, y, sprite, taken: false });
    }
    for (let i = 0; i < 12; i++) {
      const angle = i * 2.4, d = 150 + r() * 115, x = h.x + Math.cos(angle) * d, y = h.y + Math.sin(angle) * d * .74;
      if (this.solids.some(s => Math.hypot(x - s.x, y - s.y) < s.radius + 22)) continue;
      if ([[-235, 95], [260, -130], [-80, -300]].some(([dx, dy]) => Math.hypot(x - (h.x + dx * (1 + (level - 1) * .12)), y - (h.y + dy)) < 95)) continue;
      const sprite = this.add.image(x, y, 'stone').setDepth(y).setScale(.7); this.scenery.add(sprite); this.resources.push({ x, y, sprite, taken: false, kind: 'stone' });
    }
    for (const [dx, dy] of [[-235, 95], [260, -130], [-80, -300]]) {
      const x = h.x + dx * (1 + (level - 1) * .12), y = h.y + dy;
      const sprite = this.add.image(x, y, 'stump').setDepth(y).setOrigin(.5, .85); this.scenery.add(sprite); this.sources.push({ x, y, sprite, stock: level === 4 ? 180 : 36, kind: 'wood' }); this.solids.push({ x, y, radius: 25 });
      const marker = this.add.text(x, y - 67, '⌁', { fontFamily: 'Georgia', fontSize: '28px', color: '#7a6953' }).setOrigin(.5).setDepth(y + 1); this.scenery.add(marker);
    }
    this.rescue?.destroy();
    if (level > 1 && level < 4) { this.rescue = this.add.text(h.x + 405, h.y + 70, '⚑\nSTRANDED HIKER', { fontFamily: 'sans-serif', fontSize: '12px', align: 'center', color: '#284e60', backgroundColor: '#e4f0f0', padding: { x: 8, y: 7 } }).setOrigin(.5).setDepth(h.y + 70); }
    this.workers = new WorkerSystem(this, this.home, this.sources, this.solids);
  }
  start(level: Level, upgrades: Upgrades) {
    this.tweens.killAll(); this.effects.clear(true, true); this.direction.clear(); this.facing = { x: 0, y: 1 }; this.mapScale = level.size;
    this.model = new Survival(level, { ...upgrades }); this.buildForest(level.id);
    this.player.setPosition(this.home.x + 40, this.home.y + 150).setAlpha(1); this.velocity = { x: 0, y: 0 }; this.stick = { x: 0, y: 0 };
    this.activeRound = true; this.paused = false; this.actionHeld = false; this.chop = 0; this.warning = 0; this.prompt = ''; this.near = '';
    this.resize(); this.audio.ambience(true); this.hooks.changed();
  }
  menu() { this.activeRound = false; this.cancelPlacement(); this.model = undefined; this.direction?.clear(); this.paused = false; this.audio.ambience(false); this.resize(); }
  setPaused(paused: boolean) { this.paused = paused; this.cancelPlacement(); this.stick = { x: 0, y: 0 }; this.velocity = { x: 0, y: 0 }; this.actionHeld = false; this.audio.ambience(!paused && this.activeRound); }
  private get canAct() { return !!this.model && this.activeRound && !this.paused; }
  stash() {
    if (!this.canAct) return;
    if (this.near !== 'furnace') { this.hooks.feedback('Return to the furnace to store your pack.'); return; }
    const count = this.model!.settlement.stash(this.model!);
    this.hooks.feedback(count ? 'Resources stored for building. They have not been burned.' : 'Your pack is empty.'); this.hooks.changed();
  }
  feedStock() {
    if (!this.canAct) return;
    if (this.near !== 'furnace') { this.hooks.feedback('Approach the furnace to feed it from the stockpile.'); return; }
    if (this.model!.feedStock()) { this.audio.tone('deposit'); this.sparks.explode(12, this.home.x, this.home.y - 65); }
    else this.hooks.feedback('You need stored wood and room for 5 fuel.');
    this.hooks.changed();
  }
  expandFurnace() {
    if (!this.canAct) return;
    if (!this.model!.settlement.expand(this.model!)) { this.hooks.feedback('Save 30 wood in your pack and stockpile to expand the furnace.'); return; }
    this.audio.tone('deposit'); this.sparks.explode(35, this.home.x, this.home.y - 65); this.hooks.feedback('Furnace expanded! +80 warm radius.'); this.hooks.changed();
  }
  craftTools() {
    if (!this.canAct) return;
    if (this.model!.settlement.craftTools(this.model!)) { this.audio.tone('chop'); this.hooks.feedback('Stone axes crafted. Workers chop twice as fast.'); }
    else this.hooks.feedback('Stone axes cost 5 stone and can be crafted once.');
    this.hooks.changed();
  }
  beginPlacement() {
    if (!this.canAct) return;
    const m = this.model!;
    if (m.settlement.availableWood(m) < HUT_COST || m.settlement.huts >= MAX_HUTS) { this.hooks.feedback(m.settlement.huts >= MAX_HUTS ? 'Camp limit reached: four huts.' : 'A hut costs 5 wood. Gather wood or wait for a worker delivery.'); return; }
    this.placing = true;
    this.ghost?.destroy(); this.ghost = this.add.image(0, 0, 'hut').setOrigin(.5, .86).setScale(.7).setAlpha(.65);
    const spots = [{ x: -135, y: 32 }, { x: 135, y: 35 }, { x: -70, y: -100 }, { x: 90, y: -85 }];
    const spot = spots[m.settlement.huts]; this.setPlacementPoint({ x: this.home.x + spot.x, y: this.home.y + spot.y });
    this.hooks.changed();
  }
  setPlacementPoint(point: Point) {
    if (!this.placing) return;
    this.placement = { x: Math.round(point.x / 10) * 10, y: Math.round(point.y / 10) * 10 };
    const p = this.placement, m = this.model;
    this.placementValid = !!m && Math.hypot(p.x - this.home.x, (p.y - this.home.y) / .69) < m.radius - 35 && !this.solids.some(s => Math.hypot(s.x - p.x, s.y - p.y) < s.radius + 52) && Math.hypot(p.x - this.player.x, p.y - this.player.y) > 62 && Math.hypot(p.x - this.home.x, p.y - this.home.y - 84) > 100 && !this.workers?.occupies(p, 62);
    this.ghost?.setPosition(p.x, p.y).setDepth(p.y).setTint(this.placementValid ? 0xb8ffcb : 0xff8c83);
    this.hooks.changed();
  }
  cancelPlacement() { this.placing = false; this.placementValid = false; this.ghost?.destroy(); this.ghost = undefined; }
  confirmPlacement() {
    if (!this.canAct || !this.placing) return;
    this.setPlacementPoint(this.placement);
    if (!this.placementValid) { this.hooks.feedback('Choose clear ground inside the warm ring, away from people and buildings.'); return; }
    if (!this.model!.settlement.buildHut(this.model!)) { this.cancelPlacement(); this.hooks.changed(); return; }
    const p = this.placement;
    const hut = this.add.image(p.x, p.y, 'hut').setOrigin(.5, .86).setScale(.7).setDepth(p.y); this.scenery.add(hut);
    this.solids.push({ x: p.x, y: p.y, radius: 45 }); this.workers!.reroute(); this.workers!.spawn(p);
    this.cancelPlacement(); this.audio.tone('deposit'); this.hooks.feedback('Hut built. A woodcutter is heading out to gather timber.'); this.hooks.changed();
  }
  resize() {
    const { width, height } = this.scale, cam = this.cameras.main;
    const zoom = width < 650 ? Math.max(.62, Math.min(.85, height / 920)) : Math.min(1.22, Math.max(.76, height / 790));
    cam.setZoom(zoom); cam.setBounds(0, 0, 2048, 1800);
    if (this.activeRound) cam.centerOn(this.player.x, this.player.y - 65);
    else cam.centerOn(this.home.x - (width > 750 ? width * .18 / zoom : 0), this.home.y - 40);
    this.snow?.setConfig({ x: { min: -80, max: width + 180 } });
  }
  interact() {
    if (!this.activeRound || this.paused || !this.model) return;
    if (this.placing) { this.confirmPlacement(); return; }
    if (this.near === 'furnace') {
      const n = this.model.wood ? this.model.deposit() : this.model.feedStock() ? 1 : 0;
      if (n) { this.audio.tone('deposit'); this.sparks.explode(22, this.home.x, this.home.y - 65); this.float(this.home.x, this.home.y - 150, `+${n * 5} FUEL`, '#fff0ba'); this.hooks.feedback('Fire fed. Stay close to recover warmth.'); }
      else this.hooks.feedback('Gather wood for fuel, or press R / Store pack to bank stone.');
    } else if (this.near === 'rescue') {
      this.model.rescued = true; this.rescue?.setText('⚑\nHIKER RESCUED'); this.audio.tone('collect'); this.hooks.feedback('Hiker rescued. +2 embers if you survive.');
    } else if (this.near === 'source') { this.chopWood(); }
    this.hooks.changed();
  }
  private chopWood() {
    if (!this.model || !this.targetSource || this.chop > 0) return;
    if (this.model.load >= this.model.capacity) { this.hooks.feedback('Pack full. Return to the furnace and store your resources.'); return; }
    const source = this.targetSource;
    if (source.stock <= 0) return;
    source.stock--; this.model.collect(source.kind); this.chop = .7; this.audio.tone('chop'); this.float(source.x, source.y - 52, source.kind === 'wood' ? '+1 WOOD' : '+1 STONE', '#385c69');
    this.tweens.add({ targets: source.sprite, angle: 6, duration: 55, yoyo: true, repeat: 1 });
  }
  private float(x: number, y: number, label: string, color: string) {
    const t = this.add.text(x, y, label, { fontFamily: 'sans-serif', fontSize: '15px', fontStyle: 'bold', color, stroke: '#ffffff55', strokeThickness: 2 }).setOrigin(.5).setDepth(3000);
    this.effects.add(t); this.tweens.add({ targets: t, y: y - 42, alpha: 0, duration: 1050, onComplete: () => { this.effects.remove(t); t.destroy(); } });
  }
  update(_time: number, delta: number) {
    const dt = Math.min(delta / 1000, .05); this.clock += dt;
    const m = this.model, intensity = m ? m.intensity : .85;
    const warmRadius = m ? m.radius : 190;
    this.glow.setAlpha(intensity * (.75 + Math.sin(this.clock * 8) * .06)).setDisplaySize(warmRadius * 2.6, warmRadius * 1.8);
    this.furnace.setTexture(intensity > 0 ? 'furnace' : 'furnaceCold');
    this.fire.setAlpha(intensity); this.smoke.setAlpha(intensity);
    this.heat.clear();
    if (intensity > 0) { this.heat.lineStyle(2, 0xd29b57, .35); this.heat.strokeEllipse(this.home.x, this.home.y, warmRadius * 2, warmRadius * 1.38); }
    if (!this.activeRound || this.paused || !m) return;
    let ix = this.stick.x + (this.keys.D.isDown || this.cursors.right.isDown ? 1 : 0) - (this.keys.A.isDown || this.cursors.left.isDown ? 1 : 0);
    let iy = this.stick.y + (this.keys.S.isDown || this.cursors.down.isDown ? 1 : 0) - (this.keys.W.isDown || this.cursors.up.isDown ? 1 : 0);
    const length = Math.hypot(ix, iy); if (length > 1) { ix /= length; iy /= length; }
    const factor = 1 - Math.exp(-dt * 18); this.velocity.x += (ix * m.speed - this.velocity.x) * factor; this.velocity.y += (iy * m.speed - this.velocity.y) * factor;
    const { x, y } = resolveSolids({ x: this.player.x + this.velocity.x * dt, y: this.player.y + this.velocity.y * dt }, this.solids);
    this.player.setPosition(Phaser.Math.Clamp(x, this.home.x - 650 * this.mapScale, this.home.x + 650 * this.mapScale), Phaser.Math.Clamp(y, this.home.y - 590 * this.mapScale, this.home.y + 590 * this.mapScale)).setDepth(y + 1);
    const moving = Math.hypot(this.velocity.x, this.velocity.y) > 20;
    if (length > .15) this.facing = { x: ix, y: iy };
    const fx = this.facing.x, fy = this.facing.y, ax = x + fx * 27, ay = y + fy * 21;
    this.direction.clear().lineStyle(1, 0xffffff, .7).strokeEllipse(x, y - 1, 33, 18).fillStyle(0xac653a, .9).fillTriangle(ax + fx * 6, ay + fy * 5, ax - fy * 4 - fx * 3, ay + fx * 4 - fy * 3, ax + fy * 4 - fx * 3, ay - fx * 4 - fy * 3);
    this.player.setRotation(moving ? Math.sin(this.clock * 17) * .055 : Math.sin(this.clock * 2) * .012).setFlipX(ix < -.1);
    if (moving) { this.audio.tone('step'); this.trail += dt; if (this.trail > .15) { this.trail = 0; const step = this.add.ellipse(x + Math.sin(this.clock * 17) * 6, y - 1, 5, 9, 0x658b9d, .17).setDepth(.1); this.effects.add(step); this.tweens.add({ targets: step, alpha: 0, duration: 6500, onComplete: () => { this.effects.remove(step); step.destroy(); } }); } }
    for (const log of this.resources) if (!log.taken && Math.hypot(log.x - x, log.y - y) < 35 && m.collect(log.kind)) {
      log.taken = true; this.audio.tone('collect'); this.tweens.add({ targets: log.sprite, x, y: y - 45, scale: 0, alpha: 0, duration: 220, onComplete: () => log.sprite.setVisible(false) }); this.float(x, y - 65, log.kind === 'stone' ? '+1 STONE' : '+1 WOOD', '#385c69');
    }
    const distance = Math.hypot(x - this.home.x, y - this.home.y);
    this.targetSource = this.sources.filter(s => Math.hypot(s.x - x, s.y - y) < 82 && s.stock > 0).sort((a, b) => Math.hypot(a.x - x, a.y - y) - Math.hypot(b.x - x, b.y - y))[0];
    this.near = distance < 113 ? 'furnace' : this.targetSource ? 'source' : m.level.rescue && !m.rescued && Math.hypot(x - this.home.x - 405, y - this.home.y - 70) < 75 ? 'rescue' : '';
    this.prompt = this.placing ? 'Choose ground · E or Place hut to confirm' : this.near === 'furnace' ? m.wood ? `Burn ${m.wood} carried wood · R to store instead` : m.settlement.wood ? 'Feed furnace · 1 stored wood' : 'Furnace · R to store your pack' : this.near === 'source' ? m.load >= m.capacity ? 'Pack full · store resources at furnace' : this.targetSource?.kind === 'stone' ? 'Mine stone · hold to gather' : 'Chop timber · hold to gather' : this.near === 'rescue' ? 'Help the stranded hiker' : m.load >= m.capacity ? 'Pack full · return to the fire' : '';
    this.chop = Math.max(0, this.chop - dt);
    if (!this.placing && (this.actionHeld || this.keys.E.isDown || this.keys.SPACE.isDown) && this.near === 'source') this.chopWood();
    this.workers?.update(dt, m);
    m.tick(dt, Math.hypot(x - this.home.x, (y - this.home.y) / .69));
    this.cameras.main.centerOn(Phaser.Math.Linear(this.cameras.main.midPoint.x, x, dt * 2.8), Phaser.Math.Linear(this.cameras.main.midPoint.y, y - 65, dt * 2.8));
    this.warning -= dt; if (m.warmth < 30 && this.warning <= 0) { this.audio.tone('warning'); this.warning = 4; }
    this.uiClock += dt; if (this.uiClock > .1) { this.uiClock = 0; this.hooks.changed(); }
    if (m.status !== 'playing') { this.activeRound = false; this.audio.ambience(false); this.audio.tone(m.status === 'won' ? 'win' : 'lose'); this.hooks.ended(); }
  }
}
