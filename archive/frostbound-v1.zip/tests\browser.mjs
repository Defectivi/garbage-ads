import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';
import { existsSync, mkdirSync } from 'node:fs';

// Run against `npm run dev`. Set BROWSER_EXECUTABLE if using an existing browser.
const edge = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const executablePath = process.env.BROWSER_EXECUTABLE || (existsSync(edge) ? edge : undefined);
const browser = await chromium.launch({ headless: true, executablePath });
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
const errors = []; page.on('pageerror', error => errors.push(error.message));
mkdirSync('test-results', { recursive: true });
try {
  await page.goto('http://localhost:5173');
  await page.waitForSelector('.play');
  await page.screenshot({ path: 'test-results/menu-desktop.png' });
  await page.locator('.how-link').click(); await page.locator('.modal-close').click();
  await page.locator('.workshop-link').click(); assert.equal(await page.locator('.upgrade').count(), 4); await page.locator('.modal-close').click();
  await page.locator('.sound').click(); await page.locator('.sound').click();
  await page.locator('.play').click();
  await page.keyboard.down('w'); await page.waitForTimeout(650); await page.keyboard.up('w'); await page.waitForTimeout(200);
  const gathered = await page.evaluate(() => window.__frostbound.scene.model.gathered);
  assert(gathered > 0, 'Keyboard movement collects physical logs');
  assert.equal(await page.evaluate(() => window.__frostbound.scene.near), 'furnace');
  const before = await page.evaluate(() => window.__frostbound.scene.model.fuel);
  await page.keyboard.press('e'); await page.waitForTimeout(100);
  assert(await page.evaluate(() => window.__frostbound.scene.model.deposited) > 0);
  assert(await page.evaluate(() => window.__frostbound.scene.model.fuel) > before);
  await page.screenshot({ path: 'test-results/game-desktop.png' });
  await page.keyboard.down('w'); await page.waitForTimeout(300); await page.keyboard.up('w');
  const distance = await page.evaluate(() => { const s = window.__frostbound.scene; return Math.hypot(s.player.x - s.home.x, s.player.y - (s.home.y - 13)); });
  assert(distance >= 63, 'Furnace has solid collision');
  await page.locator('.pause').click(); const elapsed = await page.evaluate(() => window.__frostbound.scene.model.elapsed); await page.waitForTimeout(300);
  assert.equal(await page.evaluate(() => window.__frostbound.scene.model.elapsed), elapsed);
  await page.locator('.resume').click();

  // Accelerate real scene updates: no fuel, warmth, inventory or outcome fields are changed.
  // Walk to physical timber, chop through the interaction system, return and feed the fire.
  const expedition = await page.evaluate(() => {
    const { scene: s, game } = window.__frostbound; game.loop.sleep();
    let ticks = 0;
    const step = () => { s.update(0, 50); ticks++; };
    const walk = (x, y) => {
      let limit = 200;
      while (s.activeRound && Math.hypot(s.player.x - x, s.player.y - y) > 12 && limit-- > 0) {
        const dx = x - s.player.x, dy = y - s.player.y, d = Math.hypot(dx, dy); s.stick = { x: dx / d, y: dy / d }; step();
      }
      s.stick = { x: 0, y: 0 }; for (let i = 0; i < 8; i++) step();
    };
    // Stay south of the furnace so the route never cuts through its collider.
    for (let trip = 0; trip < 3 && s.activeRound; trip++) {
      walk(s.home.x + 65, s.home.y + 100); walk(s.home.x - 175, s.home.y + 95);
      s.actionHeld = true; for (let i = 0; i < 105 && s.activeRound; i++) step(); s.actionHeld = false;
      walk(s.home.x, s.home.y + 96); s.interact(); s.stash();
    }
    s.stick = { x: 0, y: 0 };
    while (s.activeRound && ticks < 1600) step();
    const result = { status: s.model.status, gathered: s.model.gathered, deposited: s.model.deposited, warmth: s.model.warmth, elapsed: s.model.elapsed };
    game.loop.wake(); return result;
  });
  assert.equal(expedition.status, 'won', JSON.stringify(expedition));
  assert(expedition.deposited >= 12); await page.waitForSelector('.result-panel');
  await page.screenshot({ path: 'test-results/victory.png' });
  await page.locator('.supplies').click(); await page.locator('[data-upgrade="pack"]').click(); await page.locator('.modal-close').click();
  assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem('frostbound-save')).upgrades.pack), 1);
  await page.locator('.continue').click();
  assert.equal(await page.evaluate(() => window.__frostbound.scene.model.level.id), 2);
  assert.equal(await page.evaluate(() => window.__frostbound.scene.model.capacity), 9);
  // Neglect the actual fuel and cold simulation to reach defeat.
  await page.evaluate(() => { const { scene: s, game } = window.__frostbound; game.loop.sleep(); for (let i = 0; i < 1800 && s.activeRound; i++) s.update(0, 50); game.loop.wake(); });
  await page.waitForSelector('.result-panel'); assert.match(await page.locator('.result-panel h2').textContent(), /cold/);
  await page.locator('.retry').click();
  const clean = await page.evaluate(() => { const m = window.__frostbound.scene.model; return { deposited: m.deposited, elapsed: m.elapsed, status: m.status }; });
  assert.equal(clean.deposited, 0); assert(clean.elapsed < 2); assert.equal(clean.status, 'playing');
  await page.locator('.pause').click(); await page.locator('.retry').click();
  await page.locator('.pause').click(); await page.locator('.leave').click();
  await page.reload(); await page.waitForSelector('.play');
  assert.equal(await page.locator('#level option:not([disabled])').count(), 2);
  assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem('frostbound-save')).upgrades.pack), 1);

  const mobile = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 1 });
  mobile.on('pageerror', error => errors.push(error.message));
  await mobile.goto('http://localhost:5173'); await mobile.waitForSelector('.play');
  await mobile.screenshot({ path: 'test-results/menu-mobile.png' });
  await mobile.locator('.play').tap(); await mobile.waitForTimeout(100);
  const box = await mobile.locator('#joystick').boundingBox();
  await mobile.locator('#joystick').dispatchEvent('pointerdown', { pointerId: 1, clientX: box.x + box.width / 2 + 30, clientY: box.y + box.height / 2 - 25 });
  const x = await mobile.evaluate(() => window.__frostbound.scene.player.x); await mobile.waitForTimeout(500);
  assert(await mobile.evaluate(() => window.__frostbound.scene.player.x) > x + 10, 'Touch joystick moves survivor');
  await mobile.locator('#joystick').dispatchEvent('pointerup', { pointerId: 1 });
  await mobile.screenshot({ path: 'test-results/game-mobile.png' });
  // Touch fuel interaction uses a real approach to the furnace.
  await mobile.evaluate(() => { const { scene: s, game } = window.__frostbound; game.loop.sleep(); for (let i = 0; i < 80; i++) { const dx = s.home.x + 65 - s.player.x, dy = s.home.y + 70 - s.player.y, d = Math.hypot(dx, dy); s.stick = d > 8 ? { x: dx / d, y: dy / d } : { x: 0, y: 0 }; s.update(0, 25); } s.stick = { x: 0, y: 0 }; game.loop.wake(); });
  await mobile.locator('#touch-action').tap();
  assert(await mobile.evaluate(() => window.__frostbound.scene.model.deposited) > 0, 'Touch action deposits collected wood');
  await mobile.locator('.pause').tap(); await mobile.locator('.resume').tap();
  await mobile.setViewportSize({ width: 844, height: 390 }); await mobile.waitForTimeout(200); await mobile.screenshot({ path: 'test-results/game-landscape.png' });
  assert.equal(await mobile.locator('#touch-action').isVisible(), true);
  assert.deepEqual(errors, [], 'No browser runtime errors');
  console.log('Browser checks passed: menu actions, keyboard gather/deposit, collision, pause, physical timber victory, defeat, retry, next level, upgrades, persistence, touch movement/deposit, resize.');
  console.log('Real scene expedition:', expedition);
} finally { await browser.close(); }
