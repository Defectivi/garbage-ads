import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Survival, LEVELS, freshSave, loadSave, saveProgress } from '../src/game/model';
const upgrades = () => freshSave().upgrades;
test('gathering respects capacity and deposits only carried physical wood', () => {
  const m = new Survival(LEVELS[0], upgrades());
  assert.equal(m.deposit(), 0); assert.equal(m.fuel, 16);
  for (let i = 0; i < 10; i++) m.collect();
  assert.equal(m.wood, 6); assert.equal(m.gathered, 6);
  assert.equal(m.deposit(), 6); assert.equal(m.wood, 0); assert.equal(m.fuel, 46); assert.equal(m.deposited, 6);
  assert.equal(m.deposit(), 0);
});
test('fuel consumption, storm, heat and warmth form an actual simulation', () => {
  const m = new Survival(LEVELS[0], upgrades());
  m.warmth = 50; m.tick(1, 70); assert(m.warmth > 50);
  const heat = m.temperature, outside = m.environment, warmth = m.warmth;
  m.tick(5, 500); assert(m.warmth < warmth); assert(m.temperature < heat); assert(m.environment < outside);
  m.fuel = 0; const w = m.warmth; m.tick(1, 0); assert(m.warmth < w); assert.equal(m.radius, 0);
  m.collect(); m.deposit(); assert(m.fuel > 0); assert(m.radius > 0);
});
test('neglecting the fire causes fair defeat before the first storm ends', () => {
  const m = new Survival(LEVELS[0], upgrades());
  for (let i = 0; i < 1800 && m.status === 'playing'; i++) m.tick(.05, 70);
  assert.equal(m.status, 'lost'); assert(m.elapsed > 30); assert(m.elapsed < 60);
  const elapsed = m.elapsed; m.tick(10, 0); assert.equal(m.elapsed, elapsed); assert.equal(m.collect(), false);
});
test('two delivered satchels can sustain the first expedition to victory', () => {
  const m = new Survival(LEVELS[0], upgrades());
  for (let i = 0; i < 1201; i++) {
    if (i === 100 || i === 600) { for (let n = 0; n < 6; n++) m.collect(); m.deposit(); }
    m.tick(.05, i > 40 && i < 100 || i > 520 && i < 600 ? 240 : 70);
  }
  assert.equal(m.status, 'won'); assert.equal(m.gathered, 12); assert.equal(m.deposited, 12); assert(m.fuel > 0);
});
test('each upgrade improves its specific gameplay system', () => {
  const base = new Survival(LEVELS[0], upgrades());
  const better = new Survival(LEVELS[0], { pack: 1, boots: 1, efficiency: 1, output: 1 });
  assert.equal(better.capacity, 9); assert(better.speed > base.speed); assert(better.radius > base.radius); assert(better.temperature > base.temperature);
  better.tick(1, 70); base.tick(1, 70); assert(better.fuel > base.fuel);
});
test('restart creates a clean round without mutating persistent upgrades', () => {
  const u = upgrades(), old = new Survival(LEVELS[0], u); old.collect(); old.deposit(); old.tick(9, 400);
  const next = new Survival(LEVELS[0], u); assert.equal(next.elapsed, 0); assert.equal(next.wood, 0); assert.equal(next.gathered, 0); assert.equal(next.warmth, 100); assert.equal(next.fuel, 16); assert.equal(next.status, 'playing');
});
test('save round trip, corruption handling and purchased upgrades', () => {
  const memory = new Map<string, string>();
  Object.assign(globalThis, { localStorage: { getItem: (k: string) => memory.get(k), setItem: (k: string, v: string) => memory.set(k, v) } });
  const s = freshSave(); s.unlocked = 2; s.selected = 2; s.embers = 8; s.upgrades.pack = 1; saveProgress(s);
  assert.deepEqual(loadSave(), s); memory.set('frostbound-save', 'broken'); assert.deepEqual(loadSave(), freshSave());
});
