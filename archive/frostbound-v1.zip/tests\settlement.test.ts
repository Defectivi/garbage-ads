import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Survival, CAMP_LEVEL, freshSave } from '../src/game/model';
import { Settlement } from '../src/game/settlement';
import { findRoute, resolveSolids } from '../src/game/navigation';

test('stone and wood share carrying capacity and can be stored without burning fuel', () => {
  const m = new Survival(CAMP_LEVEL, freshSave().upgrades);
  for (let i = 0; i < 3; i++) { m.collect(); m.collect('stone'); }
  assert.equal(m.load, 6); assert.equal(m.collect(), false); assert.equal(m.collect('stone'), false);
  assert.equal(m.settlement.stash(m), 6); assert.equal(m.load, 0);
  assert.equal(m.settlement.wood, 3); assert.equal(m.settlement.stone, 3); assert.equal(m.fuel, 28);
  assert(m.feedStock()); assert.equal(m.fuel, 33); assert.equal(m.settlement.wood, 2);
});
test('hut costs exactly five wood, spending storage first, with no partial failed purchase', () => {
  const e = new Settlement(), pack = { wood: 4, stone: 3 };
  assert.equal(e.buildHut(pack), false); assert.equal(pack.wood, 4); assert.equal(e.huts, 0);
  e.wood = 2; assert.equal(e.buildHut(pack), true); assert.equal(e.wood, 0); assert.equal(pack.wood, 1); assert.equal(pack.stone, 3); assert.equal(e.huts, 1);
  e.wood = 100; for (let i = 0; i < 3; i++) assert(e.buildHut(pack));
  assert.equal(e.huts, 4); const bank = e.wood; assert.equal(e.buildHut(pack), false); assert.equal(e.wood, bank);
});
test('furnace expansion costs thirty real wood and enlarges the simulated heat radius', () => {
  const m = new Survival(CAMP_LEVEL, freshSave().upgrades), radius = m.radius;
  m.settlement.wood = 29; assert.equal(m.settlement.expand(m), false); assert.equal(m.radius, radius);
  m.collect(); assert(m.settlement.expand(m)); assert.equal(m.wood, 0); assert.equal(m.settlement.wood, 0); assert.equal(m.radius, radius + 80);
  m.warmth = 50; m.tick(1, 240); assert(m.warmth > 50);
  m.fuel = 0; assert.equal(m.radius, 0, 'An expanded but extinguished furnace gives no warmth');
});
test('stone axes cost five stone, upgrade once, and do not consume wood', () => {
  const e = new Settlement(), pack = { wood: 6, stone: 4 }; assert.equal(e.craftTools(pack), false);
  e.stone = 3; assert(e.craftTools(pack)); assert.equal(e.stone, 0); assert.equal(pack.stone, 2); assert.equal(pack.wood, 6);
  e.stone = 10; assert.equal(e.craftTools(pack), false); assert.equal(e.stone, 10);
});
test('worker deliveries add only delivered stock and a restarted camp is empty', () => {
  const m = new Survival(CAMP_LEVEL, freshSave().upgrades); m.settlement.deliverWood(3);
  assert.equal(m.settlement.wood, 3); assert.equal(m.settlement.workerWood, 3); assert.equal(m.wood, 0); assert.equal(m.fuel, 28);
  const clean = new Survival(CAMP_LEVEL, freshSave().upgrades); assert.equal(clean.settlement.workerWood, 0); assert.equal(clean.settlement.huts, 0); assert.equal(clean.settlement.expansions, 0);
});
test('worker navigation routes around solids and collision resolves exact center overlap', () => {
  const solids = [{ x: 280, y: 280, radius: 65 }], from = { x: 140, y: 280 }, to = { x: 420, y: 280 };
  const route = findRoute(from, to, solids); assert(route.length > 0);
  for (const p of route) assert(Math.hypot(p.x - 280, p.y - 280) >= 81);
  const p = resolveSolids({ x: 280, y: 280 }, solids, 12); assert.equal(Math.hypot(p.x - 280, p.y - 280), 77);
});
