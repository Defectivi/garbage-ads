import Phaser from 'phaser';
export function seeded(seed: number) { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
export function createArt(scene: Phaser.Scene) {
  const texture = (key: string, w: number, h: number, draw: (c: CanvasRenderingContext2D) => void) => {
    if (scene.textures.exists(key)) return;
    const t = scene.textures.createCanvas(key, w, h)!; draw(t.context); t.refresh();
  };
  const ellipse = (c: CanvasRenderingContext2D, x: number, y: number, rx: number, ry: number, color: string) => { c.fillStyle = color; c.beginPath(); c.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2); c.fill(); };
  texture('ground', 2048, 1800, c => {
    const g = c.createLinearGradient(0, 0, 1700, 1800); g.addColorStop(0, '#b8cfd9'); g.addColorStop(.48, '#e0ebed'); g.addColorStop(1, '#a6c3d0'); c.fillStyle = g; c.fillRect(0, 0, 2048, 1800);
    const r = seeded(191);
    for (let i = 0; i < 7500; i++) { const x = r() * 2048, y = r() * 1800; ellipse(c, x, y, 1 + r() * 4, .6 + r() * 1.3, r() > .5 ? '#ffffff30' : '#5a829418'); }
    for (let i = 0; i < 90; i++) { const x = r() * 2048, y = r() * 1800; c.strokeStyle = '#ffffff26'; c.lineWidth = 2; c.beginPath(); c.ellipse(x, y, 20 + r() * 65, 4 + r() * 13, -.2, .1, 2.5); c.stroke(); }
  });
  for (let variant = 0; variant < 3; variant++) texture(`pine${variant}`, 170, 240, c => {
    const r = seeded(93 + variant * 18);
    c.save(); c.translate(100, 222); c.rotate(.17); ellipse(c, 0, 0, 63, 13, '#4567792b'); c.restore();
    c.fillStyle = '#66574b'; c.fillRect(79, 175, 12, 48); c.fillStyle = '#89735b'; c.fillRect(79, 180, 4, 41);
    for (let tier = 0; tier < 7; tier++) {
      const y = 183 - tier * 25, w = 68 - tier * 8.7;
      // Layered boughs have a shaded underside and rounded, irregular snow pillows.
      c.beginPath(); c.moveTo(85, y - 54); c.bezierCurveTo(93, y - 25, 85 + w * .58, y - 1, 85 + w, y + 9);
      for (let j = 14; j >= 0; j--) { const f = j / 14; c.lineTo(85 - w + 2 * w * f, y + 6 + Math.sin(f * Math.PI) * 21 + r() * 8); }
      c.quadraticCurveTo(72, y - 21, 85, y - 54); c.fillStyle = '#426779'; c.fill();
      const g = c.createLinearGradient(85 - w, y - 32, 85 + w, y + 20); g.addColorStop(0, '#f5f8fa'); g.addColorStop(.35, '#e8f0f5'); g.addColorStop(.7, '#b9cfdf'); g.addColorStop(1, '#88a9bf');
      c.fillStyle = g; c.beginPath(); c.moveTo(85, y - 59);
      c.bezierCurveTo(94, y - 29, 85 + w * .5, y - 9, 85 + w, y + 3);
      for (let j = 14; j >= 0; j--) { const f = j / 14, px = 85 - w + 2 * w * f, py = y + Math.sin(f * Math.PI) * 15; c.quadraticCurveTo(px + 4, py + 13 + r() * 5, px - 3, py + 3); }
      c.quadraticCurveTo(76, y - 26, 85, y - 59); c.fill();
      for (let j = 0; j < 7; j++) {
        const a = j / 6 * Math.PI, bx = 85 + Math.cos(a) * w * .73, by = y - 11 + Math.sin(a) * 18;
        c.save(); c.translate(bx, by); c.rotate((a - Math.PI / 2) * -.35);
        const snow = c.createLinearGradient(-8, -12, 12, 10); snow.addColorStop(0, '#f9fbfd'); snow.addColorStop(1, '#a2bdd0');
        c.fillStyle = snow; c.beginPath(); c.moveTo(-10, 2); c.bezierCurveTo(-14, -9, 8, -16, 13, -3); c.quadraticCurveTo(20, 11, 4, 10); c.quadraticCurveTo(-1, 7, -10, 2); c.fill(); c.restore();
      }
      c.strokeStyle = '#ffffff6b'; c.lineWidth = 1.3; c.beginPath(); c.moveTo(83, y - 48); c.quadraticCurveTo(74, y - 18, 85 - w * .7, y - 3); c.stroke();
    }
  });
  texture('rock', 85, 62, c => { ellipse(c, 45, 50, 36, 10, '#4f6c7d35'); c.fillStyle = '#718692'; c.beginPath(); c.moveTo(8, 42); c.lineTo(20, 13); c.lineTo(52, 7); c.lineTo(74, 24); c.lineTo(78, 44); c.lineTo(51, 55); c.closePath(); c.fill(); c.fillStyle = '#dbe9ed'; c.beginPath(); c.moveTo(8, 33); c.lineTo(20, 10); c.lineTo(52, 5); c.lineTo(75, 24); c.lineTo(57, 32); c.lineTo(31, 27); c.closePath(); c.fill(); });
  texture('log', 56, 30, c => { ellipse(c, 29, 24, 25, 5, '#3c617437'); c.save(); c.translate(27, 14); c.rotate(-.28); c.fillStyle = '#76503b'; c.fillRect(-21, -7, 40, 15); c.fillStyle = '#a07852'; c.fillRect(-20, -7, 40, 4); ellipse(c, 20, .5, 5, 7.5, '#d1a570'); ellipse(c, 20, .5, 2.6, 4.5, '#a8794c'); c.strokeStyle = '#4b3a2e'; c.lineWidth = 1.4; c.beginPath(); c.moveTo(-17, 4); c.lineTo(12, 4); c.stroke(); c.restore(); });
  texture('stump', 76, 65, c => { ellipse(c, 40, 54, 32, 9, '#47657433'); c.fillStyle = '#795b43'; c.fillRect(18, 25, 43, 29); ellipse(c, 39, 52, 22, 7, '#795b43'); ellipse(c, 39, 24, 24, 12, '#dbb982'); c.strokeStyle = '#9d774f'; c.lineWidth = 2; c.beginPath(); c.ellipse(39, 24, 15, 7, 0, 0, 6.3); c.stroke(); c.fillStyle = '#ecf4f2'; c.beginPath(); c.ellipse(37, 19, 24, 7, -.1, 3.1, 6.2); c.fill(); });
  texture('furnace', 180, 235, c => {
    ellipse(c, 98, 218, 76, 15, '#3e455541');
    for (const x of [50, 119]) { c.fillStyle = '#354b51'; c.fillRect(x, 167, 11, 51); }
    const metal = c.createLinearGradient(39, 0, 143, 0); metal.addColorStop(0, '#344b52'); metal.addColorStop(.38, '#658087'); metal.addColorStop(.65, '#41575c'); metal.addColorStop(1, '#253b43');
    c.fillStyle = metal; c.beginPath(); c.moveTo(57, 87); c.lineTo(124, 87); c.lineTo(145, 188); c.quadraticCurveTo(91, 216, 35, 188); c.closePath(); c.fill();
    c.fillStyle = '#2c4248'; c.fillRect(71, 29, 37, 67); ellipse(c, 89, 30, 19, 7, '#1b3036'); c.strokeStyle = '#82969a'; c.lineWidth = 4; c.beginPath(); c.ellipse(89, 29, 20, 7, 0, 0, 6.3); c.stroke();
    c.fillStyle = '#e8f0ed'; c.beginPath(); c.ellipse(87, 25, 20, 6, -.1, 3.2, 6.2); c.fill();
    c.fillStyle = '#1d2e34'; c.beginPath(); c.roundRect(55, 122, 70, 65, [27, 27, 5, 5]); c.fill();
    const fire = c.createLinearGradient(0, 123, 0, 190); fire.addColorStop(0, '#f17d32'); fire.addColorStop(1, '#ffcb6a'); c.fillStyle = fire; c.beginPath(); c.roundRect(61, 129, 58, 53, [21, 21, 3, 3]); c.fill();
    c.strokeStyle = '#263c43'; c.lineWidth = 5; for (let x = 69; x < 119; x += 15) { c.beginPath(); c.moveTo(x, 129); c.lineTo(x, 184); c.stroke(); }
    c.strokeStyle = '#879594'; c.lineWidth = 4; c.beginPath(); c.moveTo(49, 107); c.quadraticCurveTo(90, 123, 132, 107); c.moveTo(38, 188); c.quadraticCurveTo(90, 211, 144, 188); c.stroke();
    for (const x of [49, 132]) { ellipse(c, x, 111, 3, 3, '#c3c7b9'); ellipse(c, x - 3, 188, 3, 3, '#c3c7b9'); }
    c.fillStyle = '#a8bab9'; c.fillRect(119, 147, 17, 5);
  });
  texture('furnaceCold', 180, 235, c => {
    c.drawImage(scene.textures.get('furnace').getSourceImage() as HTMLCanvasElement, 0, 0);
    const image = c.getImageData(0, 0, 180, 235);
    for (let i = 0; i < image.data.length; i += 4) { if (image.data[i] > image.data[i + 1] * 1.18) { image.data[i] = 39; image.data[i + 1] = 52; image.data[i + 2] = 57; } }
    c.putImageData(image, 0, 0);
  });
  texture('survivor', 64, 90, c => {
    ellipse(c, 32, 82, 22, 6, '#334d633f');
    c.fillStyle = '#2a3e4c'; c.beginPath(); c.roundRect(19, 61, 11, 22, 4); c.roundRect(35, 61, 11, 22, 4); c.fill();
    c.fillStyle = '#b78752'; c.beginPath(); c.roundRect(12, 36, 40, 27, 9); c.fill();
    const coat = c.createLinearGradient(17, 29, 50, 60); coat.addColorStop(0, '#f2c980'); coat.addColorStop(.45, '#dca960'); coat.addColorStop(1, '#996234');
    c.fillStyle = coat; c.beginPath(); c.roundRect(17, 29, 32, 36, 9); c.fill(); c.fillStyle = '#eed29a'; c.fillRect(30, 38, 3, 26);
    c.fillStyle = '#5e706d'; c.beginPath(); c.roundRect(22, 40, 22, 24, 5); c.fill(); c.fillStyle = '#7e9386'; c.fillRect(25, 44, 16, 6);
    ellipse(c, 32, 26, 22, 23, '#b5a993'); ellipse(c, 32, 24, 18, 19, '#e7cfa8'); ellipse(c, 32, 23, 14, 15, '#ce9354');
    c.fillStyle = '#f3d8aa'; c.beginPath(); c.ellipse(32, 29, 10, 8, 0, 0, Math.PI); c.fill(); c.fillStyle = '#3b4c50'; c.fillRect(24, 25, 17, 5);
  });
  texture('worker', 64, 90, c => {
    c.drawImage(scene.textures.get('survivor').getSourceImage() as HTMLCanvasElement, 0, 0);
    const data = c.getImageData(0, 0, 64, 90);
    for (let i = 0; i < data.data.length; i += 4) if (data.data[i] > data.data[i + 2] * 1.25 && data.data[i] > 110) {
      const light = data.data[i]; data.data[i] = light * .43; data.data[i + 1] = light * .73; data.data[i + 2] = light * .87;
    }
    c.putImageData(data, 0, 0);
  });
  const polygon = (c: CanvasRenderingContext2D, points: number[][], color: string) => { c.fillStyle = color; c.beginPath(); points.forEach(([x, y], i) => i ? c.lineTo(x, y) : c.moveTo(x, y)); c.closePath(); c.fill(); };
  texture('hut', 190, 185, c => {
    ellipse(c, 100, 159, 83, 20, '#35577538');
    polygon(c, [[28, 100], [98, 122], [98, 167], [28, 145]], '#a27751');
    polygon(c, [[98, 122], [166, 91], [166, 136], [98, 167]], '#674c39');
    for (let j = 0; j < 5; j++) { c.strokeStyle = j % 2 ? '#bd9266' : '#71573f'; c.lineWidth = 3; c.beginPath(); c.moveTo(29, 108 + j * 9); c.lineTo(98, 130 + j * 9); c.lineTo(165, 99 + j * 9); c.stroke(); }
    polygon(c, [[20, 99], [77, 42], [117, 58], [98, 126]], '#6e665a');
    polygon(c, [[98, 126], [77, 42], [142, 17], [177, 88]], '#9bb6c8');
    polygon(c, [[17, 93], [74, 34], [142, 11], [181, 83], [98, 120]], '#b7cddb');
    polygon(c, [[17, 93], [74, 34], [142, 11], [111, 63], [98, 120]], '#eff5f8');
    polygon(c, [[142, 11], [181, 83], [98, 120], [111, 63]], '#c9dbe7');
    c.strokeStyle = '#f7fcff'; c.lineWidth = 6; c.lineJoin = 'round'; c.beginPath(); c.moveTo(18, 94); c.lineTo(74, 35); c.lineTo(142, 12); c.stroke();
    polygon(c, [[48, 117], [72, 124], [72, 158], [48, 151]], '#3d3630');
    polygon(c, [[52, 121], [68, 126], [68, 154], [52, 149]], '#ffb754');
    c.fillStyle = '#6e4c31'; c.fillRect(57, 124, 3, 27);
    polygon(c, [[119, 123], [143, 112], [143, 132], [119, 143]], '#ffc564');
    c.strokeStyle = '#674b38'; c.lineWidth = 3; c.beginPath(); c.moveTo(131, 117); c.lineTo(131, 137); c.moveTo(119, 133); c.lineTo(143, 122); c.stroke();
    polygon(c, [[143, 37], [153, 33], [153, 64], [143, 68]], '#5b6370');
    polygon(c, [[135, 31], [147, 26], [156, 31], [143, 37]], '#eef5f7');
    ellipse(c, 61, 163, 25, 6, '#f7fbff');
  });
  texture('stone', 44, 34, c => {
    ellipse(c, 24, 29, 18, 4, '#47697a40');
    polygon(c, [[5, 22], [13, 9], [31, 5], [40, 18], [32, 29], [13, 29]], '#698597');
    polygon(c, [[5, 22], [13, 9], [31, 5], [24, 19]], '#b7ccd8');
    polygon(c, [[24, 19], [31, 5], [40, 18], [32, 29]], '#819dad');
    c.strokeStyle = '#e6f2f3'; c.lineWidth = 2; c.beginPath(); c.moveTo(10, 17); c.lineTo(15, 10); c.lineTo(29, 7); c.stroke();
  });
  texture('glow', 512, 512, c => { const g = c.createRadialGradient(256, 256, 0, 256, 256, 256); g.addColorStop(0, '#ffb95a77'); g.addColorStop(.4, '#fbb15b45'); g.addColorStop(.8, '#f4b66a15'); g.addColorStop(1, '#ffbb6600'); c.fillStyle = g; c.fillRect(0, 0, 512, 512); });
  texture('particle', 16, 16, c => { const g = c.createRadialGradient(8, 8, 0, 8, 8, 8); g.addColorStop(0, '#fff'); g.addColorStop(1, '#ffffff00'); c.fillStyle = g; c.fillRect(0, 0, 16, 16); });
}
