export interface Point { x: number; y: number }
export interface Solid extends Point { radius: number }
export function resolveSolids(point: Point, solids: Solid[], radius = 13): Point {
  let { x, y } = point;
  for (const s of solids) {
    const dx = x - s.x, dy = y - s.y, d = Math.hypot(dx, dy), min = s.radius + radius;
    if (d < min) { x = s.x + (d ? dx / d : 1) * min; y = s.y + (d ? dy / d : 0) * min; }
  }
  return { x, y };
}
/** Small 8-way A* grid. Used only when a worker starts a trip, never every frame. */
export function findRoute(from: Point, to: Point, solids: Solid[]): Point[] {
  const cell = 28, cols = 74, rows = 65;
  const grid = (p: Point) => ({ x: Math.max(1, Math.min(cols - 2, Math.round(p.x / cell))), y: Math.max(1, Math.min(rows - 2, Math.round(p.y / cell))) });
  const start = grid(from), goal = grid(to), key = (x: number, y: number) => y * cols + x;
  const blocked = new Map<number, boolean>();
  const passable = (x: number, y: number) => {
    if (x < 1 || y < 1 || x >= cols - 1 || y >= rows - 1) return false;
    const k = key(x, y);
    if (!blocked.has(k)) blocked.set(k, solids.some(s => Math.hypot(s.x - x * cell, s.y - y * cell) < s.radius + 16));
    return !blocked.get(k);
  };
  const initial = key(start.x, start.y), target = key(goal.x, goal.y);
  const open = [initial], came = new Map<number, number>(), costs = new Map<number, number>([[initial, 0]]);
  const heuristic = (k: number) => Math.hypot(k % cols - goal.x, Math.floor(k / cols) - goal.y);
  const closed = new Set<number>(); let final = -1;
  for (let tries = 0; tries < 4800 && open.length; tries++) {
    let best = 0;
    for (let i = 1; i < open.length; i++) if (costs.get(open[i])! + heuristic(open[i]) < costs.get(open[best])! + heuristic(open[best])) best = i;
    const current = open.splice(best, 1)[0];
    if (current === target) { final = current; break; }
    closed.add(current); const x = current % cols, y = Math.floor(current / cols);
    for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) {
      if ((!dx && !dy) || !passable(x + dx, y + dy) || (dx && dy && (!passable(x + dx, y) || !passable(x, y + dy)))) continue;
      const next = key(x + dx, y + dy), cost = costs.get(current)! + (dx && dy ? Math.SQRT2 : 1);
      if (closed.has(next) || cost >= (costs.get(next) ?? Infinity)) continue;
      came.set(next, current); costs.set(next, cost); if (!open.includes(next)) open.push(next);
    }
  }
  if (final < 0) return [];
  const result: Point[] = [];
  while (final !== initial) { result.push({ x: final % cols * cell, y: Math.floor(final / cols) * cell }); final = came.get(final)!; }
  return result.reverse();
}
